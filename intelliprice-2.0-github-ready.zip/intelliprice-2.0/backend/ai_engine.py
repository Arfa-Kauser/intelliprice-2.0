"""
backend/ai_engine.py — IntelliPrice 2.0
Uses TF-IDF character n-grams for fast product grouping (no model download needed).
sentence-transformers is optional — only used if model is already cached locally.
"""
from __future__ import annotations
import os, re, logging, warnings
import numpy as np
from typing import List, Dict, Optional
warnings.filterwarnings("ignore")

log = logging.getLogger("ai_engine")


# ── Fast TF-IDF grouping (always available, zero download) ────────────────────
def _tfidf_sim_matrix(names: List[str]) -> np.ndarray:
    """Compute N×N cosine similarity matrix using char n-gram TF-IDF."""
    from sklearn.feature_extraction.text import TfidfVectorizer
    vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), min_df=1)
    M   = vec.fit_transform(names).toarray()
    # Normalise rows
    norms = np.linalg.norm(M, axis=1, keepdims=True)
    norms[norms == 0] = 1
    M /= norms
    return M @ M.T   # cosine similarity matrix


def group_by_product(items: List[Dict],
                     threshold: float = 0.62) -> List[List[Dict]]:
    """
    Cluster scraped items into same-product groups using TF-IDF cosine similarity.
    threshold 0.62 → groups same model variants, keeps distinct models separate.
    """
    if not items:
        return []
    if len(items) == 1:
        return [items]

    names = [it["product"] for it in items]
    try:
        sim = _tfidf_sim_matrix(names)
    except Exception as e:
        log.warning(f"TF-IDF grouping failed ({e}), using one-per-item.")
        return [[it] for it in items]

    assigned = [False] * len(items)
    groups: List[List[Dict]] = []

    for i in range(len(items)):
        if assigned[i]:
            continue
        grp = [items[i]]
        assigned[i] = True
        for j in range(i + 1, len(items)):
            if not assigned[j] and sim[i, j] >= threshold:
                grp.append(items[j])
                assigned[j] = True
        groups.append(grp)

    # Cheapest product group first
    groups.sort(key=lambda g: min(x["price"] for x in g))
    return groups


# ── Fake discount detection ──────────────────────────────────────────────────
def is_fake_discount(price: float, original: float) -> bool:
    return bool(original and price and original > price * 2)


# ── Offer / cashback parser ──────────────────────────────────────────────────
OFFER_KW = {
    "cashback": "💳 Cashback", "bank offer": "🏦 Bank Offer",
    "no-cost emi": "📅 No-Cost EMI", "no cost emi": "📅 No-Cost EMI",
    "flat": "🏷️ Flat Off", "extra": "➕ Extra Off",
    "coupon": "🎟️ Coupon", "exchange": "🔁 Exchange", "warranty": "🛡️ Warranty",
}

def parse_offers(offer_text: str) -> Dict:
    t    = (offer_text or "").lower()
    tags = [label for kw, label in OFFER_KW.items() if kw in t]
    cb_m = re.search(r"(\d+)\s*%\s*cashback", t)
    return {"tags": tags, "cashback_pct": float(cb_m.group(1)) if cb_m else 0.0,
            "has_offer": bool(tags)}


# ── Deal scoring ─────────────────────────────────────────────────────────────
def deal_score(item: Dict, min_p: float, max_p: float) -> float:
    """score = 0.5×price_rank + 0.3×rating_score + 0.2×discount_score ∈ [0,1]"""
    rng        = max_p - min_p
    price_sc   = (1.0 - (item["price"] - min_p) / rng) if rng > 0 else 1.0
    rating_sc  = min(item.get("rating", 0) / 5.0, 1.0)
    disc_sc    = min(item.get("discount_pct", 0) / 50.0, 1.0)
    return round(0.5 * price_sc + 0.3 * rating_sc + 0.2 * disc_sc, 4)


# ── AI comparison (per product group) ────────────────────────────────────────
def ai_compare(group: List[Dict]) -> Dict:
    if not group:
        return {}

    # ── Deduplicate: keep only the cheapest item per platform ─────────────────
    seen_platforms: Dict[str, Dict] = {}
    for item in group:
        plat = item["platform"]
        if plat not in seen_platforms or item["price"] < seen_platforms[plat]["price"]:
            seen_platforms[plat] = item
    group = list(seen_platforms.values())
    # ──────────────────────────────────────────────────────────────────────────

    prices    = [x["price"] for x in group]
    min_price = min(prices)
    max_price = max(prices)
    avg_price = sum(prices) / len(prices)
    spread    = max_price - min_price
    spread_pct = round(spread / max_price * 100, 1) if max_price > 0 else 0.0

    for item in group:
        item["deal_score"]    = deal_score(item, min_price, max_price)
        item["fake_discount"] = is_fake_discount(item["price"], item.get("original_price", 0))
        item["offer_info"]    = parse_offers(item.get("offer_text", ""))

    best     = max(group, key=lambda x: x["deal_score"])
    cheapest = min(group, key=lambda x: x["price"])

    # Recommendation text
    if spread_pct > 20:   urgency = "🔥 Massive savings available!"
    elif spread_pct > 10: urgency = "💡 Solid savings possible."
    elif spread_pct > 5:  urgency = "👍 Worth comparing platforms."
    else:                 urgency = "✅ Prices are competitive."

    rec = (f"{urgency} Best deal → <b>{best['platform']}</b> at ₹{int(best['price']):,}")
    if best.get("offer_text"): rec += f" + {best['offer_text'][:60]}"
    if spread > 0:             rec += f". Save up to ₹{int(spread):,} vs highest."

    sorted_group = sorted(group, key=lambda x: x["price"])
    cheapest_item = sorted_group[0]  # the single cheapest item

    platform_rows = []
    for rank, item in enumerate(sorted_group):
        platform_rows.append({
            "rank":           rank + 1,
            "platform":       item["platform"],
            "product":        item["product"],
            "price":          int(item["price"]),
            "original_price": int(item.get("original_price", item["price"])),
            "discount_pct":   round(item.get("discount_pct", 0), 1),
            "offer_text":     item.get("offer_text", ""),
            "offer_info":     item.get("offer_info", {}),
            "rating":         item.get("rating", 0.0),
            "url":            item.get("url", ""),
            "image":          item.get("image", ""),
            "deal_score":     item["deal_score"],
            "fake_discount":  item.get("fake_discount", False),
            "is_estimated":   item.get("is_estimated", False),
            "is_cheapest":    item is cheapest_item,
            "is_best":        item is best,
            "savings_vs_max": int(max_price - item["price"]),
        })

    return {
        "product_name":    best["product"],
        "platform_rows":   platform_rows,
        "best_platform":   best["platform"],
        "best_price":      int(best["price"]),
        "cheapest_price":  int(cheapest["price"]),
        "worst_price":     int(max_price),
        "avg_price":       int(avg_price),
        "spread":          int(spread),
        "spread_pct":      spread_pct,
        "recommendation":  rec,
        "platforms_found": len(group),
        "image":           best.get("image", ""),
    }


def ai_summary(groups: List[List[Dict]]) -> Dict:
    total = len(groups)
    plats = len({it["platform"] for g in groups for it in g})
    saving, hot = 0, []
    for g in groups:
        ps  = [x["price"] for x in g]
        sp  = max(ps) - min(ps)
        pct = round(sp / max(ps) * 100, 1) if max(ps) > 0 else 0
        saving += sp
        if pct > 10:
            b = min(g, key=lambda x: x["price"])
            hot.append({"product": b["product"][:40], "platform": b["platform"],
                        "price": int(b["price"]), "savings_pct": pct})
    hot.sort(key=lambda x: -x["savings_pct"])
    return {"total_products": total, "total_platforms": plats,
            "max_savings": int(saving), "hot_deals": hot[:5]}


# ── Price Prediction (LinearRegression) ─────────────────────────────────────
def predict_price(history: List[Dict]) -> Optional[Dict]:
    if len(history) < 3:
        return None
    try:
        from sklearn.linear_model import LinearRegression
        prices = np.array([h["price"] for h in history], dtype=float)
        X      = np.arange(len(prices)).reshape(-1, 1)
        lr     = LinearRegression().fit(X, prices)
        nxt    = float(lr.predict([[len(prices)]])[0])
        slope  = float(lr.coef_[0])
        r2     = float(lr.score(X, prices))
        cur    = float(prices[-1])

        # ── Reality cap: predicted price must not deviate more than 10% from current ──
        # Real e-commerce prices rarely jump more than 10% between observations
        max_dev = cur * 0.10
        nxt = max(cur - max_dev, min(cur + max_dev, nxt))

        pct = (nxt - cur) / cur * 100 if cur > 0 else 0

        # ── Trend & advice based on ACTUAL predicted vs current comparison ──
        # This ensures recommendation always matches the numbers shown to the user
        if nxt < cur * 0.98:          # >2% drop predicted
            trend  = "dropping"
            advice = "📉 Price is dropping! Wait a few more days for a potential further dip."
        elif nxt > cur * 1.02:        # >2% rise predicted
            trend  = "rising"
            advice = "🚀 Price is rising! Buy now before it goes even higher."
        elif nxt <= cur:              # slight drop or same
            trend  = "stable"
            advice = "✅ Price is stable with a slight dip. Good time to buy!"
        else:                         # slight rise
            trend  = "stable"
            advice = "✅ Price is stable with a minor uptick. Consider buying now."

        # Confidence score
        conf = round(max(r2, 0) * 100, 1)
        if len(history) > 10:
            conf = max(conf, 85.0)

        # ── Explanation referencing actual price values ──
        if trend == "dropping":
            expl = (f"The predicted price (₹{round(nxt):,}) is {abs(round(pct, 1))}% lower "
                    f"than the current price (₹{int(cur):,}). "
                    f"The average change per observation is ₹{abs(int(slope)):,}, "
                    f"indicating a consistent downward trend. Waiting may save you more.")
        elif trend == "rising":
            expl = (f"The predicted price (₹{round(nxt):,}) is {round(pct, 1)}% higher "
                    f"than the current price (₹{int(cur):,}). "
                    f"Prices are trending up at ~₹{int(slope):,} per observation. "
                    f"Buying now is recommended to avoid higher costs.")
        else:
            expl = (f"The predicted price (₹{round(nxt):,}) is very close to the current "
                    f"price (₹{int(cur):,}), with minor fluctuations of ~₹{abs(int(slope)):,} "
                    f"per observation. The market is stable — a safe time to purchase.")

        return {"predicted_price": round(nxt), "current_price": int(cur),
                "trend": trend, "slope": round(slope, 2), "pct_change": round(pct, 1),
                "advice": advice, "confidence": conf, "explanation": expl}
    except Exception as e:
        log.error(f"Price prediction error: {e}")
        return None


# ── RandomForest deal model ──────────────────────────────────────────────────
MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                          "models", "ml_model.pkl")

def _feats(item: Dict) -> List[float]:
    return [item.get("price", 0), item.get("original_price", item.get("price", 0)),
            item.get("discount_pct", 0), item.get("rating", 0),
            1 if item.get("offer_text") else 0]

def train_ml_model(data: List[Dict]) -> None:
    if len(data) < 5: return
    try:
        import joblib
        from sklearn.ensemble import RandomForestRegressor
        X = np.array([_feats(d) for d in data])
        y = np.array([d.get("deal_score", 0.5) for d in data])
        model = RandomForestRegressor(n_estimators=50, random_state=42)
        model.fit(X, y)
        os.makedirs(os.path.dirname(MODEL_PATH), exist_ok=True)
        joblib.dump(model, MODEL_PATH)
    except Exception as e:
        log.debug(f"ML train: {e}")

def ml_predict_score(item: Dict) -> Optional[float]:
    if not os.path.exists(MODEL_PATH): return None
    try:
        import joblib
        return float(joblib.load(MODEL_PATH).predict([_feats(item)])[0])
    except: return None
