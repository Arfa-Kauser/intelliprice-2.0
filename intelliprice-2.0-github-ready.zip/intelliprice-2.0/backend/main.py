"""
backend/main.py
FastAPI backend for IntelliPrice 2.0
Endpoints: /search /compare /predict-price /alerts /wishlist /auth
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import logging, uuid, re

from backend.db       import (init_db, authenticate, create_user, get_user,
                              add_wishlist, remove_wishlist, get_wishlist,
                              set_alert, get_alerts, get_alert_for, remove_alert,
                              trigger_alert, record_price, get_price_history,
                              create_session, get_user_by_session, delete_session,
                              get_latest_product_image, save_product_image, reset_alert)
from backend.scraper  import scrape_all, fetch_simulated_history
from backend.ai_engine import (group_by_product, ai_compare, ai_summary,
                                predict_price, train_ml_model, ml_predict_score)

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s")
log = logging.getLogger("main")

app = FastAPI(
    title="IntelliPrice",
    description="AI-powered electronics price comparison backend",
    version="2.0.0",
)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])
init_db()


# ── Pydantic models ───────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    email:    str
    password: str

class RegisterRequest(BaseModel):
    email:     str
    name:      str
    password:  str
    platforms: str = "Amazon,Flipkart,Croma,Reliance Digital"

class WishlistRequest(BaseModel):
    email:   str
    product: str

class AlertRequest(BaseModel):
    email:        str
    product:      str
    target_price: float

class AlertResetRequest(BaseModel):
    email:   str
    product: str


# ── Auth ──────────────────────────────────────────────────────────────────────
@app.post("/auth/login")
def login(req: LoginRequest):
    user = authenticate(req.email, req.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    sid = str(uuid.uuid4())
    create_session(user["email"], sid)
    
    return {"status": "ok", "email": user["email"], "name": user["name"],
            "platforms": user["platforms"], "session_id": sid}

@app.get("/auth/session")
def get_session_info(sid: str = Query(...)):
    user = get_user_by_session(sid)
    if not user:
        raise HTTPException(status_code=404, detail="Invalid session")
    return {"status": "ok", "email": user["email"], "name": user["name"],
            "platforms": user["platforms"]}

@app.delete("/auth/logout")
def logout(sid: str = Query(...)):
    delete_session(sid)
    return {"status": "ok"}

@app.post("/auth/register")
def register(req: RegisterRequest):
    if len(req.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long")
    ok = create_user(req.email, req.name, req.password, req.platforms)
    if not ok:
        raise HTTPException(status_code=409, detail="Email already exists")
    return {"status": "ok", "email": req.email}


# ── Search & Compare ──────────────────────────────────────────────────────────
@app.get("/search")
def search(
    q:         str  = Query(..., description="Product search query"),
    platforms: str  = Query("Amazon,Flipkart,Croma,Reliance Digital"),
    email:     Optional[str] = Query(None),
):
    """
    1. Scrape all platforms
    2. NLP-group identical products
    3. AI-compare each group
    4. Record prices in DB
    5. Check alerts
    6. Return structured results
    """
    plat_list = [p.strip() for p in platforms.split(",") if p.strip()]

    # Step 1 — Scrape
    raw = scrape_all(q, plat_list)
    if not raw:
        return {"query": q, "groups": [], "summary": {},
                "message": "No results. Platforms may be blocking requests."}

    # Step 2 — Group
    groups = group_by_product(raw, threshold=0.68)

    # Step 3 — AI compare + Step 4 — record prices
    results = []
    all_items_flat = []
    for grp in groups:
        cmp = ai_compare(grp)
        if not cmp: continue

        # Record to DB + initial history if needed
        for row in cmp["platform_rows"]:
            # Check existing history
            existing = get_price_history(row["product"], row["platform"], days=180)
            if not existing:
                log.info(f"Populating simulated history for {row['product']} on {row['platform']}")
                sim = fetch_simulated_history(row["product"], row["platform"], row["price"])
                from backend.db import record_bulk_history
                record_bulk_history(row["product"], row["platform"], sim)
            else:
                record_price(row["product"], row["platform"], row["price"])
            # Save product image to DB for later use (e.g., predictions)
            if row.get("image") and row["image"].startswith("http"):
                save_product_image(row["product"], row["platform"], row["image"])
            all_items_flat.append(row)

        # Step 5 — Check alerts
        alert_hit = False
        if email:
            target = get_alert_for(email, cmp["product_name"])
            if target and cmp["best_price"] <= target:
                alert_hit = True
                trigger_alert(email, cmp["product_name"])

        cmp["alert_hit"] = alert_hit
        results.append(cmp)

    # Train ML model with fresh data (async would be better in prod)
    try:
        train_ml_model(all_items_flat)
    except: pass

    summary = ai_summary(groups)
    return {"query": q, "groups": results, "summary": summary}


@app.get("/compare")
def compare(products: str = Query(..., description="Comma-separated product names")):
    """Compare a specific list of product names across the DB history."""
    names = [p.strip() for p in products.split(",")]
    result = {}
    for name in names:
        hist = get_price_history(name)
        result[name] = hist
    return result


# ── Price Prediction ──────────────────────────────────────────────────────────
@app.get("/predict-price")
def predict(
    product:  str = Query(...),
    platform: str = Query("Amazon"),
):
    """
    Returns AI price prediction for a product on specific platform.
    If history is missing, it dynamically populates it from a live scrape.
    """
    hist = get_price_history(product, platform, days=120)
    
    # Fallback to simulation if still not enough (fixed for platform switching)
    if len(hist) < 3:
        # Always include Amazon as a baseline for the estimation engine
        plats_to_scrape = list(set([platform, "Amazon"]))
        p_info = scrape_all(product, plats_to_scrape)
        
        # If no results on the requested platform, try a simplified search
        if not any(it["platform"] == platform for it in p_info):
            simple_q = re.sub(r"[\(\[].*?[\)\]]", "", product).strip()
            if simple_q != product:
                log.info(f"Query simplified for {platform}: {product} -> {simple_q}")
                p_info = scrape_all(simple_q, plats_to_scrape)
        
        # Filter for the requested platform's results
        plat_info = [it for it in p_info if it["platform"] == platform]
        
        if plat_info:
            from difflib import SequenceMatcher
            best_match = max(plat_info, key=lambda x: SequenceMatcher(None, product.lower(), x["product"].lower()).ratio())
            
            log.info(f"Dynamic history population for prediction: {product} on {platform} (Best match: {best_match['product']})")
            # Use price from best_match to generate simulation
            sim = fetch_simulated_history(product, platform, best_match["price"])
            from backend.db import record_bulk_history
            record_bulk_history(product, platform, sim)
            hist = get_price_history(product, platform, days=120)
            # Store best_match for image logic later
            active_match = best_match

    # Re-check history length
    if len(hist) < 3:
        return {"error": f"Not enough price history yet for '{product}' on {platform}. Please search this product on its platform first."}

    res = predict_price(hist)
    if res:
        res["product_name"] = product
        res["platform"]     = platform

        # Image retrieval: try live scrape data first (best match), then DB, then quick scrape
        image = ""
        if 'active_match' in locals() and active_match.get("image"):
            image = active_match["image"]
        elif 'p_info' in locals() and p_info:
            # Find image from same platform first, then any
            plat_imgs = [it.get("image", "") for it in p_info if it["platform"] == platform and it.get("image")]
            any_imgs  = [it.get("image", "") for it in p_info if it.get("image")]
            image = (plat_imgs[0] if plat_imgs else any_imgs[0]) if (plat_imgs or any_imgs) else ""

        if not image:
            image = get_latest_product_image(product, platform) or ""

        # Last resort: quick Amazon scrape for image only
        if not image:
            try:
                quick = scrape_all(product, ["Amazon"])
                for it in quick:
                    if it.get("image") and it["image"].startswith("http"):
                        image = it["image"]
                        save_product_image(product, it["platform"], image)
                        break
            except:
                pass

        res["image"] = image
        return res
    
    return {"error": "Prediction failed due to insufficient data points."}


# ── Price History ─────────────────────────────────────────────────────────────
@app.get("/price-history")
def price_history(product: str = Query(...), platform: str = Query(None)):
    hist = get_price_history(product, platform)
    return {"product": product, "platform": platform, "history": hist}


# ── History Images ────────────────────────────────────────────────────────────
@app.get("/search/history-images")
def history_images(queries: str = Query(...)):
    """Fetch latest images for a list of comma-separated search queries."""
    q_list = [q.strip() for q in queries.split(",") if q.strip()]
    results = []
    for q in q_list:
        img = get_latest_product_image(q)
        results.append({"query": q, "image": img or ""})
    return {"items": results}


# ── Wishlist ──────────────────────────────────────────────────────────────────
@app.get("/wishlist")
def wishlist_get(email: str = Query(...)):
    items = get_wishlist(email)
    results = []
    for item in items:
        # Try to find the latest image for this product
        img = get_latest_product_image(item)
        results.append({"product": item, "image": img or ""})
    return {"items": results}


@app.post("/wishlist")
def wishlist_add(req: WishlistRequest):
    add_wishlist(req.email, req.product)
    return {"status": "ok"}

@app.delete("/wishlist")
def wishlist_del(email: str = Query(...), product: str = Query(...)):
    remove_wishlist(email, product)
    return {"status": "ok"}


# ── Alerts ────────────────────────────────────────────────────────────────────
@app.get("/alerts")
def alerts_get(email: str = Query(...)):
    return {"alerts": get_alerts(email)}

@app.post("/alerts")
def alerts_set(req: AlertRequest):
    set_alert(req.email, req.product, req.target_price)
    return {"status": "ok"}

@app.delete("/alerts")
def alerts_del(email: str = Query(...), product: str = Query(...)):
    remove_alert(email, product)
    return {"status": "ok"}

@app.post("/alerts/reset")
def alerts_reset(req: AlertResetRequest):
    reset_alert(req.email, req.product)
    return {"status": "ok"}


# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {"status": "IntelliPrice 2.0 API running", "version": "2.0.0"}

@app.get("/health")
def health():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
