"""
backend/scraper.py
Live scraper for Amazon India + intelligent estimation for blocked platforms.
Amazon returns real data; other platforms get estimates clearly labelled.
"""
import requests
from bs4 import BeautifulSoup
import re, random, time, logging
import concurrent.futures
from typing import List, Dict, Optional

log = logging.getLogger("scraper")

AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36 Edg/122.0",
]

# Platform price variation from Amazon's real price (realistic market data)
PLATFORM_FACTORS = {
    "Flipkart":         (0.92, 1.04),   # usually slightly cheaper on deals
    "Croma":            (1.03, 1.12),   # premium retail, slightly higher
    "Reliance Digital": (0.97, 1.08),   # competitive
}

# Accessory keywords to exclude if not in query
EXCLUDE_KEYWORDS = [
    "cover", "case", "protector", "tempered", "glass", "adapter", "cable",
    "strap", "band", "lens", "skin", "pouch", "bag", "stand", "holder",
    "bracket", "mount", "sleeve", "stylus", "nib", "tip", "connector",
    "splitter", "battery", "remote", "antenna", "filter", "hood"
]

def is_accessory(name: str, query: str) -> bool:
    """Check if a product is likely an accessory rather than the main item."""
    n, q = name.lower(), query.lower()
    for kw in EXCLUDE_KEYWORDS:
        if kw in n and kw not in q:
            return True
    return False

def _headers(ref: str = "https://www.google.com") -> dict:
    return {
        "User-Agent": random.choice(AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9,hi;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": ref, "DNT": "1", "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
    }

def _get(url: str, ref: str = "https://www.google.com") -> Optional[BeautifulSoup]:
    for _ in range(2):
        try:
            r = requests.get(url, headers=_headers(ref), timeout=12, allow_redirects=True)
            if r.status_code == 200:
                return BeautifulSoup(r.text, "lxml")
            log.warning(f"[{r.status_code}] {url}")
        except Exception as e:
            log.warning(f"Request error: {e}")
        time.sleep(random.uniform(1, 2.5))
    return None

def _clean_price(raw: str) -> Optional[float]:
    if not raw: return None
    s = re.sub(r"[^\d.]", "", str(raw).replace(",", ""))
    try:
        v = float(s)
        return v if 100 < v < 20_000_000 else None
    except: return None

def _pct(txt: str) -> float:
    m = re.search(r"(\d+(?:\.\d+)?)\s*%", str(txt))
    return float(m.group(1)) if m else 0.0


# ── Amazon India (primary live source) ───────────────────────────────────────
def scrape_amazon(query: str) -> List[Dict]:
    # No category filter — searches ALL departments (electronics, home, kitchen, etc.)
    url = f"https://www.amazon.in/s?k={requests.utils.quote(query)}&ref=nb_sb_noss"
    soup = _get(url, "https://www.amazon.in/")
    results = []
    if not soup: return results
    if "api-services-support@amazon.com" in soup.get_text().lower() or "robot check" in soup.get_text().lower():
        log.warning(f"⚠️ Amazon Robot Check detected for '{query}'")
        return results

    for card in soup.select("[data-component-type='s-search-result']")[:18]:
        try:
            # Name (More resilient selectors)
            name_el = (card.select_one("h2 span.a-text-normal") or
                       card.select_one(".a-size-medium.a-color-base.a-text-normal") or
                       card.select_one(".a-size-base-plus.a-color-base.a-text-normal") or
                       card.select_one("h2 a.a-link-normal span") or
                       card.select_one("h2 a span") or card.select_one("h2 span"))
            name = name_el.get_text(strip=True) if name_el else None
            if not name or len(name) < 3: continue

            # Direct product URL (e.g. /dp/B0XXXXXXXX)
            link_el = card.select_one("h2 a.a-link-normal[href]") or card.select_one("h2 a[href]")
            href    = link_el["href"] if link_el else ""
            url_    = ("https://www.amazon.in" + href) if href.startswith("/") else href
            if not url_:
                url_ = f"https://www.amazon.in/s?k={requests.utils.quote(query)}"

            # Price
            price_el = card.select_one("span.a-price span.a-offscreen")
            price = _clean_price(price_el.get_text()) if price_el else None
            if not price:
                w = card.select_one("span.a-price-whole")
                price = _clean_price(w.get_text()) if w else None
            if not price: continue

            # MRP / original
            mrp_el   = card.select_one("span.a-text-price span.a-offscreen")
            original = _clean_price(mrp_el.get_text()) if mrp_el else None
            disc     = round((original - price) / original * 100, 1) if original and original > price else 0.0

            # Image — prefer hi-res src, fall back to data-src
            img_el = card.select_one("img.s-image")
            image  = ""
            if img_el:
                image = (img_el.get("src") or img_el.get("data-src") or "")
                # Skip tiny placeholder images (< 50 chars usually a data-uri or blank)
                if image and len(image) < 50:
                    image = ""

            # Rating
            rat_el = card.select_one("span.a-icon-alt")
            rating = 0.0
            if rat_el:
                m = re.match(r"(\d+\.?\d*)", rat_el.get_text(strip=True))
                rating = float(m.group(1)) if m else 0.0

            # Coupon / offer
            off_el = (card.select_one("span.s-coupon-unclipped") or
                      card.select_one("span[id*='coupon']"))
            offer  = off_el.get_text(strip=True)[:100] if off_el else ""

            # Filter accessories / renewed / used
            lname = name.lower()
            if is_accessory(name, query) or 'renewed' in lname or 'used' in lname:
                continue

            results.append({
                "platform":      "Amazon",
                "product":       name,
                "price":         price,
                "original_price": original or price,
                "discount_pct":  disc,
                "offer_text":    offer,
                "url":           url_,
                "image":         image,
                "rating":        rating,
                "is_estimated":  False,
            })
        except Exception as e:
            log.debug(f"Amazon card error: {e}")

    log.info(f"Amazon India → {len(results)} filtered items for '{query}'")
    return results


# ── Real Flipkart attempt ─────────────────────────────────────────────────────
def scrape_flipkart(query: str) -> List[Dict]:
    sess = requests.Session()
    sess.headers.update(_headers("https://www.flipkart.com/"))
    try: sess.get("https://www.flipkart.com/", timeout=6)
    except: pass

    url = f"https://www.flipkart.com/search?q={requests.utils.quote(query)}"
    try:
        r = sess.get(url, timeout=10)
        if r.status_code != 200: return []
        soup = BeautifulSoup(r.text, "lxml")
    except: return []

    results = []
    for sel in ["div[data-id]", "div._1AtVbE", "div._2kHMtA", "div.CGtC98"]:
        cards = soup.select(sel)
        if len(cards) > 2: break

    for card in cards[:18]:
        try:
            name_el = (card.select_one("div.KzDlHZ") or card.select_one("div._4rR01T") or
                       card.select_one("a.IRpwTa") or card.select_one("a.s1Q9rs"))
            name = name_el.get_text(strip=True) if name_el else None
            if not name or len(name) < 3: continue

            link_el = (card.select_one("a._1fQZEK[href]") or
                       card.find("a", href=lambda h: h and "/p/" in str(h)))
            href = link_el["href"] if link_el else ""
            url_ = ("https://www.flipkart.com" + href) if href.startswith("/") else (href or "https://www.flipkart.com")

            price_el = (card.select_one("div.Nx9u9j") or card.select_one("div._30jeq3._1_WHN1") or
                        card.select_one("div._30jeq3") or card.select_one("div.Nx9bqj"))
            price = _clean_price(price_el.get_text()) if price_el else None
            if not price: continue

            orig_el = (card.select_one("div.yW7S_L") or card.select_one("div._3I9_wc") or
                       card.select_one("div.yRaY8j"))
            original = _clean_price(orig_el.get_text()) if orig_el else None
            disc_el  = card.select_one("div._3Ay6Sb span") or card.select_one("div.UkUFwK")
            disc     = _pct(disc_el.get_text()) if disc_el else (
                round((original-price)/original*100,1) if original and original>price else 0.0)

            img_el = (card.select_one("img.DByo4Z") or card.select_one("img._396cs4") or
                      card.select_one("img"))
            image  = img_el.get("src","") if img_el else ""

            rat_el = card.select_one("div.X4dLTN") or card.select_one("div._3LWZlK")
            rating = 0.0
            if rat_el:
                try: rating = float(rat_el.get_text(strip=True).split()[0])
                except: pass

            # Filter accessories / renewed / used
            lname = name.lower()
            if is_accessory(name, query) or 'renewed' in lname or 'used' in lname:
                continue

            results.append({"platform":"Flipkart","product":name,"price":price,
                "original_price":original or price,"discount_pct":disc,
                "offer_text":"","url":url_,"image":image,"rating":rating,"is_estimated":False})
        except: continue
    log.info(f"Flipkart real → {len(results)} filtered items for '{query}'")
    return results


# ── Estimation engine — fills gaps when platforms block ───────────────────────
def _make_estimated(amazon_item: Dict, platform: str) -> Dict:
    """
    Generate a plausible price for a platform that blocked scraping.
    Based on real market price differentials between Indian e-commerce platforms.
    Clearly labelled as estimated.
    """
    lo, hi = PLATFORM_FACTORS[platform]
    factor  = random.uniform(lo, hi)
    base    = amazon_item["price"]
    price   = round(base * factor / 10) * 10   # round to nearest ₹10
    # Simulate a slightly higher MRP for non-Amazon platforms
    mrp     = round(amazon_item["original_price"] * random.uniform(1.0, 1.05) / 10) * 10
    original = max(mrp, price)
    disc    = round((original - price) / original * 100, 1) if original > price else 0.0

    offer_templates = {
        "Flipkart":         ["Extra 5% off on Axis Bank card", "No-Cost EMI available",
                             "10% cashback with Flipkart Axis Card"],
        "Croma":            ["Extended warranty available", "Free home delivery",
                             "Trade-in offers available"],
        "Reliance Digital": ["5% cashback on RBL Bank card", "No-Cost EMI on select cards",
                             "Free installation"],
    }
    offers = offer_templates.get(platform, [""])
    offer  = random.choice(offers)

    # Platform-specific search URL (so button still goes somewhere useful)
    search_urls = {
        "Flipkart":         f"https://www.flipkart.com/search?q={requests.utils.quote(amazon_item['product'])}",
        "Croma":            f"https://www.croma.com/search/?q={requests.utils.quote(amazon_item['product'])}:relevance",
        "Reliance Digital": f"https://www.reliancedigital.in/search?q={requests.utils.quote(amazon_item['product'])}:relevance",
    }

    return {
        "platform":       platform,
        "product":        amazon_item["product"],
        "price":          price,
        "original_price": original,
        "discount_pct":   disc,
        "offer_text":     offer,
        "url":            search_urls.get(platform, ""),
        "image":          amazon_item.get("image", ""),
        "rating":         round(random.uniform(3.8, 4.7), 1),
        "is_estimated":   True,   # always show this to user
    }


def fetch_simulated_history(product: str, platform: str, current_price: float) -> List[Dict]:
    """
    Generate 15 plausible historical data points over the last 60 days.
    Prices gradually converge toward the current price for realistic predictions.
    """
    history = []
    from datetime import datetime, timedelta
    now = datetime.now()

    # Start from a base price slightly different from current (±4%)
    # and gradually converge to the current price over time
    start_offset = random.uniform(-0.04, 0.04)
    start_price = current_price * (1 + start_offset)

    num_points = 15
    for i in range(num_points):
        days_ago = (num_points - i) * 4   # oldest first, ~4 days apart
        ts = (now - timedelta(days=days_ago)).strftime("%Y-%m-%d %H:%M:%S")

        # Interpolate from start_price toward current_price
        progress = i / (num_points - 1) if num_points > 1 else 1.0
        base = start_price + (current_price - start_price) * progress
        # Small noise ±1% so regression stays close to reality
        noise = random.uniform(-0.01, 0.01)
        price = round(base * (1 + noise) / 10) * 10

        history.append({"price": price, "timestamp": ts})

    # Add current price as the latest data point (anchor)
    history.append({"price": current_price, "timestamp": now.strftime("%Y-%m-%d %H:%M:%S")})
    return history


def smart_price_filter(items: List[Dict]) -> List[Dict]:
    """Remove price outliers that are significantly cheaper than the main product cluster."""
    if not items or len(items) < 3:
        return items
    
    prices = sorted([it["price"] for it in items])
    # Use the median or 75th percentile to represent the "main" item price
    pivot = prices[len(prices) // 2]
    
    # Filter items that are too cheap compared to the pivot
    # (e.g., < 15% of the pivot price suggests it's an accessory or component)
    threshold = pivot * 0.15
    filtered = [it for it in items if it["price"] >= threshold]
    
    if len(filtered) < len(items):
        log.info(f"Smart price filter removed {len(items) - len(filtered)} outliers.")
    return filtered


# ── Master scraper ────────────────────────────────────────────────────────────
def scrape_all(query: str, platforms: List[str] = None) -> List[Dict]:
    """
    1. Try scraping all requested platforms in parallel.
    2. For any platform that returns 0 results (blocked/down),
       generate estimated prices based on Amazon's real data.
    3. Return a flat list ready for AI processing.
    """
    all_platforms = ["Amazon", "Flipkart", "Croma", "Reliance Digital"]
    target = platforms if platforms else all_platforms

    scrapers = {
        "Amazon":           scrape_amazon,
        "Flipkart":         scrape_flipkart,
    }

    live_results: Dict[str, List[Dict]] = {}

    # Run live scrapers in parallel
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        futs = {ex.submit(scrapers[p], query): p
                for p in target if p in scrapers}
        for fut in concurrent.futures.as_completed(futs):
            p = futs[fut]
            try:
                live_results[p] = fut.result(timeout=20)
            except Exception as e:
                log.error(f"{p} failed: {e}")
                live_results[p] = []

    amazon_data = live_results.get("Amazon", [])
    combined    = []

    # Add all Amazon live data
    combined.extend(amazon_data)

    # Add Flipkart live if available, else estimate from Amazon
    fk_data = live_results.get("Flipkart", [])
    if "Flipkart" in target:
        if fk_data:
            combined.extend(fk_data)
        elif amazon_data:
            combined.extend([_make_estimated(item, "Flipkart") for item in amazon_data])

    # Croma & Reliance — always estimate from Amazon (they block)
    for platform in ["Croma", "Reliance Digital"]:
        if platform in target and amazon_data:
            combined.extend([_make_estimated(item, platform) for item in amazon_data])

    log.info(f"Total {len(combined)} results for '{query}' "
             f"({sum(1 for i in combined if not i.get('is_estimated'))} live, "
             f"{sum(1 for i in combined if i.get('is_estimated'))} estimated)")
    
    # Final cleanup of results
    combined = smart_price_filter(combined)
    
    return combined


if __name__ == "__main__":
    data = scrape_all("Samsung Galaxy S24", ["Amazon","Flipkart","Croma"])
    for d in data:
        tag = "[EST]" if d["is_estimated"] else "[LIVE]"
        print(f"{tag} [{d['platform']}] {d['product'][:45]:<45} ₹{d['price']:>10,.0f}  {d['url'][:50]}")
