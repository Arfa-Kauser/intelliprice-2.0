"""
backend/db.py
SQLite database layer for IntelliPrice 2.0
Tables: users, wishlist, alerts, price_history, sessions
"""
import sqlite3
import os
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any

# DB path — one level up from backend/
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH  = os.path.join(BASE_DIR, "database", "intelliprice.db")


def get_conn() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row          # dict-like rows
    conn.execute("PRAGMA journal_mode=WAL") # concurrent reads
    return conn


def init_db() -> None:
    """Create all tables if they don't exist."""
    conn = get_conn()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        email       TEXT    UNIQUE NOT NULL,
        name        TEXT    NOT NULL,
        password    TEXT    NOT NULL,
        platforms   TEXT    DEFAULT 'Amazon,Flipkart,Croma,Reliance Digital',
        created_at  TEXT    DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS wishlist (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        email       TEXT    NOT NULL,
        product     TEXT    NOT NULL,
        added_at    TEXT    DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(email, product)
    );

    CREATE TABLE IF NOT EXISTS alerts (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        email        TEXT    NOT NULL,
        product      TEXT    NOT NULL,
        target_price REAL    NOT NULL,
        triggered    INTEGER DEFAULT 0,
        created_at   TEXT    DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(email, product)
    );

    CREATE TABLE IF NOT EXISTS price_history (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        product   TEXT    NOT NULL,
        platform  TEXT    NOT NULL,
        price     REAL    NOT NULL,
        timestamp TEXT    DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sessions (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id  TEXT    UNIQUE NOT NULL,
        email       TEXT    NOT NULL,
        created_at  TEXT    DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS product_images (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        product    TEXT    NOT NULL,
        platform   TEXT    DEFAULT '',
        image_url  TEXT    NOT NULL,
        updated_at TEXT    DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(product, platform)
    );

    CREATE INDEX IF NOT EXISTS idx_ph_product ON price_history(product, platform);
    CREATE INDEX IF NOT EXISTS idx_sessions_sid ON sessions(session_id);
    """)
    conn.commit()
    conn.close()


# ── Users ─────────────────────────────────────────────────────────────────────
def create_user(email: str, name: str, password: str, platforms: str) -> bool:
    try:
        conn = get_conn()
        conn.execute("INSERT INTO users (email, name, password, platforms) VALUES (?,?,?,?)",
                     (email, name, password, platforms))
        conn.commit(); conn.close()
        return True
    except sqlite3.IntegrityError:
        return False


def get_user(email: str) -> Optional[Dict]:
    conn = get_conn()
    row = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    conn.close()
    return dict(row) if row else None


def authenticate(email: str, password: str) -> Optional[Dict]:
    u = get_user(email)
    return u if (u and u["password"] == password) else None


# ── Sessions ──────────────────────────────────────────────────────────────────
def create_session(email: str, session_id: str) -> bool:
    try:
        conn = get_conn()
        conn.execute("INSERT OR REPLACE INTO sessions (session_id, email) VALUES (?,?)",
                     (session_id, email))
        conn.commit(); conn.close()
        return True
    except: return False


def get_user_by_session(session_id: str) -> Optional[Dict]:
    conn = get_conn()
    row = conn.execute("""
        SELECT u.* FROM users u
        INNER JOIN sessions s ON u.email = s.email
        WHERE s.session_id = ?
    """, (session_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def delete_session(session_id: str) -> None:
    conn = get_conn()
    conn.execute("DELETE FROM sessions WHERE session_id=?", (session_id,))
    conn.commit(); conn.close()


# ── Wishlist ──────────────────────────────────────────────────────────────────
def add_wishlist(email: str, product: str) -> bool:
    try:
        conn = get_conn()
        conn.execute("INSERT OR IGNORE INTO wishlist (email,product) VALUES (?,?)",
                     (email, product))
        conn.commit(); conn.close()
        return True
    except: return False


def remove_wishlist(email: str, product: str) -> None:
    conn = get_conn()
    conn.execute("DELETE FROM wishlist WHERE email=? AND product=?", (email, product))
    conn.commit(); conn.close()


def get_wishlist(email: str) -> List[str]:
    conn = get_conn()
    rows = conn.execute("SELECT product FROM wishlist WHERE email=? ORDER BY added_at DESC",
                        (email,)).fetchall()
    conn.close()
    return [r["product"] for r in rows]


# ── Alerts ────────────────────────────────────────────────────────────────────
def set_alert(email: str, product: str, target_price: float) -> None:
    conn = get_conn()
    conn.execute("""INSERT INTO alerts (email,product,target_price)
                   VALUES (?,?,?)
                   ON CONFLICT(email,product) DO UPDATE SET target_price=?, triggered=0""",
                 (email, product, target_price, target_price))
    conn.commit(); conn.close()


def get_alerts(email: str) -> List[Dict]:
    conn = get_conn()
    rows = conn.execute("SELECT * FROM alerts WHERE email=? ORDER BY created_at DESC",
                        (email,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_alert_for(email: str, product: str) -> Optional[float]:
    conn = get_conn()
    row = conn.execute("SELECT target_price FROM alerts WHERE email=? AND product=?",
                       (email, product)).fetchone()
    conn.close()
    return row["target_price"] if row else None


def remove_alert(email: str, product: str) -> None:
    conn = get_conn()
    conn.execute("DELETE FROM alerts WHERE email=? AND product=?", (email, product))
    conn.commit(); conn.close()


def trigger_alert(email: str, product: str) -> None:
    conn = get_conn()
    conn.execute("UPDATE alerts SET triggered=1 WHERE email=? AND product=?",
                 (email, product))
    conn.commit(); conn.close()


def reset_alert(email: str, product: str) -> None:
    """Reset the alert to 'Watching' (triggered=0)."""
    conn = get_conn()
    conn.execute("UPDATE alerts SET triggered=0 WHERE email=? AND product=?",
                 (email, product))
    conn.commit(); conn.close()


# ── Price History ─────────────────────────────────────────────────────────────
def record_price(product: str, platform: str, price: float, timestamp: str = None) -> None:
    """Store a price observation."""
    conn = get_conn()
    if timestamp:
        conn.execute("INSERT INTO price_history (product,platform,price,timestamp) VALUES (?,?,?,?)",
                     (product, platform, price, timestamp))
    else:
        conn.execute("INSERT INTO price_history (product,platform,price) VALUES (?,?,?)",
                     (product, platform, price))
    conn.commit(); conn.close()


def record_bulk_history(product: str, platform: str, history: List[Dict[str, Any]]) -> None:
    """Insert multiple points at once."""
    conn = get_conn()
    points = [(product, platform, h["price"], h["timestamp"]) for h in history]
    conn.executemany("INSERT INTO price_history (product,platform,price,timestamp) VALUES (?,?,?,?)",
                     points)
    conn.commit(); conn.close()


def get_price_history(product: str, platform: str = None,
                      days: int = 30) -> List[Dict]:
    conn = get_conn()
    if platform:
        rows = conn.execute("""
            SELECT price, timestamp FROM price_history
            WHERE product=? AND platform=?
              AND timestamp >= datetime('now',?)
            ORDER BY timestamp ASC
        """, (product, platform, f"-{days} days")).fetchall()
    else:
        rows = conn.execute("""
            SELECT platform, price, timestamp FROM price_history
            WHERE product=? AND timestamp >= datetime('now',?)
            ORDER BY timestamp ASC
        """, (product, f"-{days} days")).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_all_products_with_history() -> List[str]:
    conn = get_conn()
    rows = conn.execute(
        "SELECT DISTINCT product FROM price_history ORDER BY product"
    ).fetchall()
    conn.close()
    return [r["product"] for r in rows]


def save_product_image(product: str, platform: str, image_url: str) -> None:
    """Store or update the image URL for a product on a platform."""
    if not image_url or not image_url.startswith("http"):
        return
    conn = get_conn()
    conn.execute(
        """INSERT INTO product_images (product, platform, image_url, updated_at)
           VALUES (?, ?, ?, CURRENT_TIMESTAMP)
           ON CONFLICT(product, platform)
           DO UPDATE SET image_url=?, updated_at=CURRENT_TIMESTAMP""",
        (product, platform, image_url, image_url))
    conn.commit()
    conn.close()


def get_latest_product_image(product: str, platform: str = None) -> Optional[str]:
    """Retrieve the most recent image URL for a product.
    Tries exact product+platform first, then any platform for that product."""
    conn = get_conn()
    row = None
    if platform:
        row = conn.execute(
            "SELECT image_url FROM product_images WHERE product=? AND platform=? ORDER BY updated_at DESC LIMIT 1",
            (product, platform)).fetchone()
    if not row:
        row = conn.execute(
            "SELECT image_url FROM product_images WHERE product=? AND image_url != '' ORDER BY updated_at DESC LIMIT 1",
            (product,)).fetchone()
    conn.close()
    return row["image_url"] if row else None


# Initialise on import
init_db()
