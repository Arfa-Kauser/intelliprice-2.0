"""
frontend/app.py — IntelliPrice 2.0  (Purple/Violet theme, fixed layout)
"""
import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import streamlit as st
import requests as req
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

st.set_page_config(page_title="IntelliPrice 2.0", page_icon="💰",
                   layout="wide", initial_sidebar_state="collapsed")

API = "http://localhost:8000"

def api(method, path, **kwargs):
    try:
        r = getattr(req, method)(f"{API}{path}", timeout=90, **kwargs)
        if r.status_code == 200: return r.json()
        try:
            err_msg = r.json().get('detail', r.text[:200])
        except Exception:
            err_msg = r.text[:200]
        st.error(f"API error {r.status_code}: {err_msg}")
    except req.exceptions.ConnectionError:
        st.error("⚠️ Backend offline — run: `python -m uvicorn backend.main:app --port 8000`")
    except req.exceptions.Timeout:
        st.error("⏱️ Request timed out. Backend may be loading AI models. Try again.")
    except Exception as e:
        st.error(f"Error: {e}")
    return None

# ── CSS — Purple/Violet gradient theme ────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;700&display=swap');

*, *::before, *::after {
  box-sizing: border-box;
}
html, body, [data-testid="stAppViewContainer"], .stApp {
  font-family: 'Inter', sans-serif !important;
}
html, body {
  overflow-y: auto !important;
  overflow-x: hidden !important;
  background: var(--bg) !important;
  color: var(--text) !important;
}
/* Multiple selectors for Streamlit version resilience */
[data-testid="stAppViewContainer"],
.stApp,
.main,
section.main,
[class*="css"] {
  background: var(--bg-grad) !important;
  min-height: 100vh;
  color: var(--text) !important;
}
[data-testid="stHeader"],
header[data-testid="stHeader"] { background: transparent !important; box-shadow: none !important; }
[data-testid="stSidebar"],
section[data-testid="stSidebar"] { display: none !important; }
[data-testid="stAppViewBlockContainer"],
[data-testid="block-container"],
.block-container {
  overflow: visible !important;
  padding-top: 0.5rem !important;
  max-width: 1200px;
}

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: var(--tab-bg); }
::-webkit-scrollbar-thumb { background: var(--acc-grad); border-radius: 4px; }

/* ── Global text — broad net ── */
body, .stApp, .main, section.main {
  color: var(--text) !important;
}
p, span, div, label, li, a,
[data-testid="stMarkdownContainer"] p,
[data-testid="stMarkdownContainer"] span,
[data-testid="stMarkdownContainer"] li,
[data-testid="stMarkdownContainer"] div,
[data-testid="stMarkdownContainer"] label,
.stTextInput label, .stSelectbox label,
.stMultiSelect label, .stNumberInput label {
  color: var(--text) !important;
}

/* ── Text inputs & Password — aggressive dark theme overrides ── */
/* Base layer — catch all raw inputs */
input,
input[type="text"],
input[type="search"],
input[type="password"],
input[type="email"],
input[type="number"],
textarea {
  background: var(--inp-bg) !important;
  color: var(--text) !important;
  -webkit-text-fill-color: var(--text) !important;
  caret-color: var(--acc) !important;
}

/* Streamlit text input wrapper — every nesting level */
div[data-testid="stTextInput"] input,
div[data-testid="stTextInput"] > div input,
div[data-testid="stTextInput"] > div > div input,
div[data-testid="stTextInput"] > div > div > input,
div[data-testid="stTextInput"] > label + div input,
.stTextInput input,
.stTextInput > div > div > input {
  background: #FFFFFF !important;
  border: 1.5px solid var(--bord) !important;
  border-radius: 12px !important;
  color: #000000 !important;
  -webkit-text-fill-color: #000000 !important;
  font-size: 15px !important;
  padding: 12px 16px !important;
  transition: border-color .2s, box-shadow .2s, background .2s !important;
  box-shadow: inset 0 2px 8px rgba(0,0,0,.15) !important;
}

/* Focus state */
div[data-testid="stTextInput"] input:focus,
div[data-testid="stTextInput"] > div > div > input:focus,
.stTextInput input:focus {
  border-color: var(--acc) !important;
  box-shadow: 0 0 0 3px var(--bord), inset 0 2px 8px rgba(0,0,0,.1) !important;
  background: #FFFFFF !important;
  color: #000000 !important;
  -webkit-text-fill-color: #000000 !important;
  outline: none !important;
}

/* Placeholder */
div[data-testid="stTextInput"] input::placeholder,
div[data-testid="stTextInput"] > div > div > input::placeholder,
.stTextInput input::placeholder {
  color: var(--text-muted) !important;
  -webkit-text-fill-color: var(--text-muted) !important;
}

/* Browser autofill override — kills white autofill background */
input:-webkit-autofill,
input:-webkit-autofill:hover,
input:-webkit-autofill:focus,
input:-webkit-autofill:active {
  -webkit-box-shadow: 0 0 0 1000px var(--surf) inset !important;
  -webkit-text-fill-color: var(--text) !important;
  caret-color: var(--acc) !important;
  border: 1.5px solid var(--bord) !important;
  border-radius: 12px !important;
  transition: background-color 9999s ease-in-out 0s !important;
}

/* ── Selectbox / multiselect ── */
div[data-testid="stSelectbox"] > div,
div[data-testid="stMultiSelect"] > div {
  background: var(--inp-bg) !important;
  border: 1.5px solid var(--bord) !important;
  border-radius: 12px !important;
}

/* ── Selected text ── */
div[data-baseweb="select"] span {
  color: #000000 !important;
  font-weight: 700 !important;
}

/* Input layer */
div[data-baseweb="select"] input {
  color: var(--text) !important;
  caret-color: transparent !important;   /* remove | cursor */
  pointer-events: none !important;       /* disable typing */
}

/* Multi-select tags */
div[data-baseweb="tag"] {
  background: #4338CA !important;
  color: #FFFFFF !important;
  border-radius: 6px !important;
}
div[data-baseweb="tag"] * {
  color: #FFFFFF !important;
  -webkit-text-fill-color: #FFFFFF !important;
  font-weight: 700 !important;
}

/* Placeholder */
div[data-baseweb="select"] input::placeholder {
  color: var(--text-muted) !important;
}

/* Dropdown menu container */
div[data-baseweb="menu"] {
  background: var(--surf) !important;  /* force dark */
  border: 1px solid var(--bord) !important;
  border-radius: 12px !important;
  box-shadow: var(--shdow) !important;
}

/* Fix inner dropdown panel (important for Streamlit bug) */
[data-testid="stSelectboxVirtualDropdown"],
[data-testid="stMultiSelectDropdown"] {
  background: var(--surf) !important;  /* override white panel */
}

/* Each option row and Dataframe menus */
li[role="option"],
div[role="menuitem"],
div[data-baseweb="option"],
[data-testid="stSelectboxVirtualDropdown"] li,
[data-testid="stMultiSelectDropdown"] li {
  background: transparent !important;
  color: #000000 !important;  /* Force dark text for visibility in white menus */
  -webkit-text-fill-color: #000000 !important;
  font-size: 13px !important;
  font-weight: 600 !important;
}

/* Option hover */
li[role="option"]:hover,
div[data-baseweb="option"]:hover,
li[role="option"][aria-selected="true"] {
  background: var(--acc) !important;
  color: var(--btn-txt) !important;
}

/* Checked/selected option tick */
li[role="option"][aria-selected="true"] {
  background: var(--tab-bg) !important;
  color: var(--acc) !important;
}

/* Multiselect tags */
span[data-baseweb="tag"] {
  background: var(--tab-bg) !important;
  border-radius: 6px !important;
  color: var(--text) !important;
  border: 1px solid var(--bord) !important;
  padding: 3px 8px !important;
  height: auto !important;
  max-width: fit-content !important;
}
span[data-baseweb="tag"] span { 
  color: #000000 !important; 
  font-size: 11px !important; 
  font-weight: 800 !important;
}
div[data-baseweb="tag"] {
  background: var(--tab-bg) !important;
  color: #000000 !important;
}

/* Browser native autocomplete / datalist suggestions */
input:-webkit-autofill-selected { background: var(--surf) !important; color: var(--text) !important; }

/* Listbox (browser suggestion popup) — limited but best effort */
::-webkit-list-button { background: var(--surf) !important; color: var(--text) !important; }
optgroup, option {
  background: var(--surf) !important;
  color: var(--text) !important;
}

/* ── Selectbox / Multiselect labels ── */
div[data-testid="stSelectbox"] label,
div[data-testid="stMultiSelect"] label {
  color: var(--text) !important;
  font-weight: 800 !important;
  font-size: 13px !important;
}
/* Selected text inside closed box */
div[data-baseweb="select"] > div,
div[data-baseweb="select"] > div > div,
div[data-baseweb="select"] [data-testid="stWidgetLabel"],
div[data-baseweb="select"] input,
div[data-baseweb="select"] [class*="Placeholder"],
div[data-baseweb="select"] [class*="SingleValue"],
div[data-baseweb="select"] [class*="Value"] {
  color: #000000 !important;
  -webkit-text-fill-color: #000000 !important;
  font-weight: 800 !important;
}

/* Ensure multiselect container doesn't clip tags */
div[data-testid="stMultiSelect"] > div:nth-child(2) {
  overflow: visible !important;
  min-height: 48px !important;
}
div[data-baseweb="select"] {
  overflow: visible !important;
}

/* ── Radio buttons (Sort By: Best Deals / Ratings / etc.) ── */
.stRadio > label,
.stRadio > div > label,
[data-testid="stRadio"] > label {
  color: var(--text) !important;
  font-weight: 800 !important;
  font-size: 13px !important;
}
/* Each radio option label */
.stRadio [data-testid="stWidgetLabel"],
.stRadio label[data-baseweb="radio"] span,
.stRadio div[role="radiogroup"] label,
.stRadio div[role="radiogroup"] p,
.stRadio div[role="radiogroup"] span,
[data-testid="stRadio"] label,
[data-testid="stRadio"] p,
[data-testid="stRadio"] span {
  color: var(--text) !important;
  font-size: 13px !important;
  font-weight: 700 !important;
}
/* Radio dot — outer ring */
.stRadio div[role="radiogroup"] label [data-baseweb="radio"] {
  border-color: var(--bord) !important;
  background: var(--tab-bg) !important;
}
/* Radio dot — selected fill */
.stRadio div[role="radiogroup"] label [data-baseweb="radio"][aria-checked="true"] {
  border-color: var(--acc) !important;
  background: var(--acc) !important;
}
/* Checkbox labels */
.stCheckbox label span,
.stCheckbox label p,
[data-testid="stCheckbox"] span,
[data-testid="stCheckbox"] p {
  color: var(--text) !important;
  font-size: 13px !important;
  font-weight: 700 !important;
}

/* Trending Buttons (Chips) */
.trend-btn button {
  background: var(--tab-bg) !important;
  color: var(--text) !important;
  -webkit-text-fill-color: var(--text) !important;
  border: 1px solid var(--bord) !important;
  border-radius: 20px !important;
  padding: 6px 16px !important;
  font-size: 13px !important;
  font-weight: 700 !important;
  transition: all 0.3s ease !important;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05) !important;
  width: auto !important;
}
.trend-btn button p {
  color: var(--text) !important;
  -webkit-text-fill-color: var(--text) !important;
  margin-bottom: 0 !important;
}
.trend-btn button:hover {
  background: var(--acc) !important;
  color: var(--btn-txt) !important;
  -webkit-text-fill-color: var(--btn-txt) !important;
  border-color: var(--acc) !important;
  transform: scale(1.05) !important;
  box-shadow: 0 5px 15px rgba(139,92,246,0.2) !important;
}
.trend-btn button:hover p {
  color: var(--btn-txt) !important;
  -webkit-text-fill-color: var(--btn-txt) !important;
}

/* ── Buttons ── */
div[data-testid="stButton"] button,
div[data-testid="stFormSubmitButton"] button,
.stButton button {
  background-color: #1E1B4B !important; 
  background: var(--btn-bg) !important;
  color: #FFFFFF !important;
  -webkit-text-fill-color: #FFFFFF !important;
  border: 1px solid #4C1D95 !important;
  border-radius: 12px !important;
  padding: 8px 18px !important;
  font-weight: 800 !important;
  font-size: 14px !important;
  letter-spacing: .4px !important;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
  box-shadow: 0 4px 12px rgba(0,0,0,0.4) !important;
  width: 100% !important;
}

div[data-testid="stButton"] button *,
div[data-testid="stFormSubmitButton"] button * {
  color: var(--btn-txt) !important;
  -webkit-text-fill-color: var(--btn-txt) !important;
}

div[data-testid="stButton"] button:hover,
div[data-testid="stFormSubmitButton"] button:hover {
  transform: translateY(-2px) !important;
  box-shadow: 0 8px 24px rgba(139,92,246,0.3) !important;
  filter: brightness(1.1) !important;
}

div[data-testid="stButton"] button:active {
  transform: translateY(0) !important;
}

/* ── Link buttons (Buy on Flipkart etc.) ── */
div[data-testid="stLinkButton"] a {
  background: var(--btn-bg) !important;
  color: var(--btn-txt) !important;
  -webkit-text-fill-color: var(--btn-txt) !important;
  border: 1px solid var(--bord) !important;
  border-radius: 12px !important;
  padding: 10px 16px !important;
  text-decoration: none !important;
  font-weight: 800 !important;
  font-size: 13px !important;
  display: block !important;
  text-align: center !important;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
  box-shadow: 0 4px 15px rgba(0,0,0,0.15) !important;
}

div[data-testid="stLinkButton"] a:hover {
  transform: translateY(-3px) !important;
  box-shadow: 0 10px 28px rgba(139,92,246,0.4) !important;
  filter: brightness(1.1) !important;
}

/* ── Tabs ── */
.stTabs [data-baseweb="tab-list"] {
  background: rgba(139,92,246,.08) !important;
  border-radius: 12px !important;
  padding: 4px !important;
  gap: 3px !important;
  border: 1px solid rgba(139,92,246,.2) !important;
}
.stTabs [data-baseweb="tab"] {
  background: transparent !important;
  color: rgba(200,180,255,.55) !important;
  border-radius: 9px !important;
  font-weight: 700 !important;
  font-size: 13px !important;
  padding: 7px 18px !important;
}
.stTabs [aria-selected="true"] {
  background: var(--tab-act) !important;
  color: #fff !important;
  box-shadow: 0 4px 14px rgba(124,58,237,.45) !important;
}
.stTabs [data-baseweb="tab-highlight"],
.stTabs [data-baseweb="tab-border"] { display: none !important; }

/* ── Number input ── */
div[data-testid="stNumberInput"] > div > div > input {
  background: var(--tab-bg) !important;
  border: 1.5px solid var(--bord) !important;
  border-radius: 10px !important;
  color: var(--text) !important;
  padding: 10px 14px !important;
}

/* ── Hero ── */
.hero {
  background: var(--hero-bg);
  border: 1px solid var(--bord);
  border-radius: 20px;
  padding: 26px 32px;
  margin-bottom: 20px;
  position: relative; overflow: hidden;
  backdrop-filter: blur(20px);
  box-shadow: var(--shdow), inset 0 1px 0 rgba(255,255,255,.06);
}
.hero::after {
  content: '';
  position: absolute; top: -40%; right: -5%;
  width: 360px; height: 360px;
  background: radial-gradient(circle, rgba(139,92,246,.12), transparent 65%);
  border-radius: 50%;
  animation: hglow 8s ease-in-out infinite alternate;
}
@keyframes hglow { from{transform:scale(1)} to{transform:scale(1.2) translateY(-15px)} }
.hero-title {
  font-size: 22px; font-weight: 800; color: var(--text) !important;
  margin-bottom: 8px; position: relative; z-index: 1;
}
.hero-sub {
  font-size: 13px; color: var(--text-muted) !important;
  line-height: 1.7; position: relative; z-index: 1;
}

/* ── Brand ── */
.brand-logo {
  font-size: 36px; font-weight: 900; line-height: 1.1;
  background: linear-gradient(90deg, #A78BFA, #EC4899, #06B6D4);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}
.brand-sub { font-size: 11px; color: rgba(167,139,250,.5) !important; letter-spacing: .6px; }

/* ── Pills / badges ── */
.pill-ai { display:inline-flex; align-items:center;
  background: linear-gradient(135deg,#7C3AED,#EC4899);
  color:#fff !important; border-radius:20px; padding:3px 12px;
  font-size:10px; font-weight:800; letter-spacing:.5px; margin-left:8px;
  vertical-align:middle; box-shadow:0 2px 12px rgba(124,58,237,.5); }
.badge-plat { display:inline-block; background:rgba(139,92,246,.15);
  border:1px solid rgba(139,92,246,.35); border-radius:6px; padding:2px 9px;
  font-size:10px; font-weight:700; color:#C4B5FD !important; letter-spacing:.4px; }
.badge-save { display:inline-block; background:rgba(16,185,129,.12);
  border:1px solid rgba(16,185,129,.3); border-radius:6px; padding:2px 9px;
  font-size:10px; font-weight:700; color:#6EE7B7 !important; }
.badge-est { display:inline-block; background:rgba(245,158,11,.1);
  border:1px solid rgba(245,158,11,.3); border-radius:6px; padding:2px 8px;
  font-size:9px; font-weight:700; color:#FCD34D !important; }
.badge-fake { display:inline-block; background:rgba(239,68,68,.1);
  border:1px solid rgba(239,68,68,.3); border-radius:6px; padding:2px 8px;
  font-size:9px; font-weight:700; color:#FCA5A5 !important; }
.badge-alert { display:inline-block; background:rgba(245,158,11,.12);
  border:1px solid rgba(245,158,11,.35); border-radius:6px; padding:2px 9px;
  font-size:10px; font-weight:700; color:#FCD34D !important; }

/* ── Stat cards ── */
.stat-card {
  background: var(--tab-bg);
  border: 1px solid var(--bord);
  border-radius: 16px; padding: 16px; text-align: center;
  transition: transform .25s, box-shadow .25s; position:relative; overflow:hidden;
}
.stat-card::before {
  content:''; position:absolute; top:0; left:0; right:0; height:2px;
  background: linear-gradient(90deg,#7C3AED,#EC4899,#06B6D4); opacity:.8;
}
.stat-card:hover { transform:translateY(-4px); box-shadow:0 12px 32px rgba(139,92,246,.2); }
.stat-val { font-size:26px; font-weight:900;
  background:linear-gradient(90deg,#A78BFA,#EC4899);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.stat-lbl { font-size:10px; color:var(--text-muted) !important;
  font-weight:700; letter-spacing:1px; text-transform:uppercase; margin-top:4px; }

/* ── Trending chips ── */
.trend-wrap { display:flex; flex-wrap:wrap; gap:8px; margin:10px 0 16px; }
/* ── Trending chips ── */
.trend-chip {
  display:inline-block;
  background: var(--tab-bg);
  border: 1.5px solid var(--bord);
  border-radius:20px; padding:6px 16px;
  font-size:12px; font-weight:700;
  color:var(--text) !important; white-space:nowrap;
}

/* ── Search panel ── */
.search-panel {
  background: var(--hero-bg);
  border: 1.5px solid var(--bord);
  border-radius: 20px; padding: 22px 24px; margin-bottom: 20px;
  backdrop-filter: blur(12px);
}
.search-row {
  margin-bottom: 12px;
}
.search-title { font-size:16px; font-weight:800; color:var(--text) !important; margin-bottom:4px; }
.search-sub { font-size:12px; color:var(--text-muted) !important; margin-bottom:6px; }
.live-badge { display:inline-block;
  background:linear-gradient(135deg,#10B981,#06B6D4);
  color:#fff !important; border-radius:20px; padding:2px 10px;
  font-size:10px; font-weight:800; letter-spacing:.4px; margin-left:8px; }

/* ── Hot deals ── */
.hot-wrap {
  background: var(--hero-bg);
  border:1px solid var(--bord); border-radius:16px;
  padding:14px 18px; margin-bottom:18px;
}
.hot-pill {
  display:inline-block; background:rgba(255,255,255,.05);
  border:1px solid rgba(167,139,250,.2); border-radius:18px;
  padding:4px 13px; margin:3px; font-size:12px; color:#DDD6FE !important;
}

/* ── Product card ── */
.pcard {
  background: var(--card-bg);
  border: 1px solid var(--bord);
  border-radius: 20px; padding: 18px 16px 14px; margin-bottom: 18px;
  transition: transform .3s, box-shadow .3s, border-color .3s;
  position:relative; overflow:hidden; backdrop-filter:blur(10px);
}
.pcard::before {
  content:''; position:absolute; top:0; left:0; right:0; height:1px;
  background: linear-gradient(90deg,transparent,rgba(139,92,246,.6),transparent);
  opacity:0; transition:opacity .3s;
}
.pcard:hover { transform:translateY(-5px); border-color:rgba(139,92,246,.45);
  box-shadow:0 18px 55px rgba(139,92,246,.18); }
.pcard:hover::before { opacity:1; }
.pcard-name { font-size:14px; font-weight:800; color:var(--text) !important;
  line-height:1.35; margin-bottom:6px; }
.pcard-meta { display:flex; gap:5px; flex-wrap:wrap; margin-bottom:10px; }

/* ── AI box ── */
.ai-box {
  background: var(--ai-bg);
  border: 1px solid var(--bord);
  border-left: 3px solid var(--ai-txt);
  border-radius: 10px; padding: 10px 13px; margin: 10px 0 12px;
}
.ai-box-title { font-size:10px; font-weight:800; color:var(--ai-txt) !important;
  letter-spacing:.6px; margin-bottom:4px; }
.ai-box-rec { font-size:12px; color:#FEF3C7 !important; line-height:1.6; }
.ai-avg { font-size:11px; color:rgba(253,230,138,.6) !important; margin-top:3px; }
.ai-best { color:#6EE7B7 !important; font-weight:700; }

/* ── Platform rows ── */
.plat-row { border-radius:11px; padding:10px 13px; margin-bottom:7px;
  transition:transform .18s; }
.plat-row:hover { transform:translateX(4px); }
.pr-1 { background:rgba(16,185,129,.08); border:1px solid rgba(16,185,129,.3);
  border-left:4px solid #10B981; }
.pr-2 { background:rgba(139,92,246,.07); border:1px solid rgba(139,92,246,.2);
  border-left:4px solid rgba(139,92,246,.6); }
.pr-3 { background:rgba(245,158,11,.07); border:1px solid rgba(245,158,11,.2);
  border-left:4px solid rgba(245,158,11,.6); }
.pr-4 { background:rgba(239,68,68,.07); border:1px solid rgba(239,68,68,.2);
  border-left:4px solid rgba(239,68,68,.6); }
.plat-name { font-size:12px; font-weight:700; color:rgba(220,210,255,.85) !important; }
.plat-price { font-family:'JetBrains Mono',monospace !important;
  font-size:21px; font-weight:700; color:var(--text) !important; margin:3px 0 1px; }
.plat-orig { font-size:11px; color:rgba(150,130,200,.45) !important;
  text-decoration:line-through; margin-left:6px; }
.plat-best { font-size:10px; font-weight:800; color:#6EE7B7 !important;
  background:rgba(16,185,129,.12); border-radius:5px; padding:1px 7px; }
.plat-disc { font-size:10px; font-weight:800; color:#FCD34D !important;
  background:rgba(245,158,11,.12); border-radius:5px; padding:1px 7px; margin-left:4px; }
.offer-pill { display:inline-block; background:rgba(167,139,250,.12);
  border:1px solid rgba(167,139,250,.25); border-radius:6px;
  padding:3px 9px; font-size:10px; color:#C4B5FD !important; margin-top:5px; }
.score-bg { background:rgba(255,255,255,.06); border-radius:4px;
  height:4px; margin-top:6px; overflow:hidden; }
.score-bar { height:4px; border-radius:4px;
  background:linear-gradient(90deg,#7C3AED,#10B981); }
.score-txt { font-size:9px; color:rgba(167,139,250,.4) !important; margin-top:2px; }

/* ── Compare / wishlist panel ── */
.compare-panel { background:rgba(16,185,129,.05);
  border:1.5px solid rgba(16,185,129,.25);
  border-radius:16px; padding:16px 20px; margin-bottom:16px; }
.wl-item { 
  background: var(--card-bg) !important;
  border: 1px solid var(--bord) !important;
  border-radius: 16px !important;
  padding: 16px !important;
  display: flex !important;
  align-items: center !important;
  gap: 16px !important;
  margin-bottom: 12px !important;
  transition: transform .2s, box-shadow .2s;
  backdrop-filter: blur(12px);
}
.wl-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(139,92,246,0.15);
}
.wl-img {
  width: 80px; height: 80px;
  border-radius: 10px;
  object-fit: contain;
  background: rgba(255,255,255,0.05);
  border: 1px solid var(--bord);
}
.wl-content { flex-grow: 1; }
.wl-name {
  font-size: 15px; font-weight: 800;
  color: var(--text) !important;
  line-height:1.4; margin-bottom: 4px;
}

/* ── Login card ── */
.login-glass {
  background: var(--surf);
  border: 1px solid var(--bord);
  border-radius: 22px; padding: 32px 28px;
  backdrop-filter: blur(24px);
  box-shadow: var(--shdow);
}

/* ── Pred boxes ── */
.pred-up { background:rgba(239,68,68,.08); border:1px solid rgba(239,68,68,.25);
  border-radius:11px; padding:10px 14px; font-size:13px; color:#FCA5A5 !important; }
.pred-down { background:rgba(16,185,129,.08); border:1px solid rgba(16,185,129,.25);
  border-radius:11px; padding:10px 14px; font-size:13px; color:#6EE7B7 !important; }
.pred-stable { background:rgba(139,92,246,.08); border:1px solid rgba(139,92,246,.25);
  border-radius:11px; padding:10px 14px; font-size:13px; color:#C4B5FD !important; }

/* ── No result ── */
.no-res { background:rgba(245,158,11,.06); border:1px solid rgba(245,158,11,.2);
  border-radius:14px; padding:20px 24px; }

/* ── Footer ── */
.footer { text-align:center; padding:24px; color:var(--text-muted) !important;
  font-size:12px; border-top:1px solid var(--bord); margin-top:16px; }

/* ── Info / warning / error override ── */
[data-testid="stAlert"] { border-radius:12px !important; border: 1.5px solid var(--bord) !important; background: var(--surf) !important; }
div[data-testid="stAlert"] p { color: var(--text) !important; font-weight: 700 !important; }
[data-testid="stTooltipContent"] { background-color: #1E1B4B !important; color: #FFFFFF !important; border: 1px solid #4338CA !important; font-weight: 600 !important; }
[data-testid="stTooltipHoverTarget"] { color: #FFFFFF !important; }

/* ── Search history vertical ── */

/* ── Search history vertical ── */
.hist-item {
    display: flex;
    align-items: center;
    background: #FFFFFF !important;  /* Force white background for history items for max contrast */
    border: 1.5px solid var(--bord) !important;
    border-radius: 12px !important;
    padding: 2px 10px !important;
    margin-bottom: 10px !important;
    transition: all 0.22s !important;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1) !important;
}
.hist-item:hover {
    border-color: var(--acc) !important;
    background: #F3F4F6 !important;
    transform: translateX(4px) !important;
}
.hist-item button {
    background: transparent !important;
    border: none !important;
    color: #000000 !important;  /* Force black text for history searches */
    -webkit-text-fill-color: #000000 !important;
    padding: 10px !important;
    text-align: left !important;
    flex-grow: 1 !important;
    font-weight: 700 !important;
}
.hist-item button:hover {
    background: rgba(167,139,250,0.1) !important;
}

/* ── Toast Notifications (Purple Theme Gradient) ── */
div[data-testid="stToast"], 
[data-testid="stToast"], 
div[role="alert"] {
    background: linear-gradient(135deg, #7C3AED, #4C1D95) !important;
    background-color: #4C1D95 !important;
    color: #FFFFFF !important;
    border-radius: 14px !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.45) !important;
    padding: 12px 16px !important;
    min-width: 320px !important;
}
div[data-testid="stToast"] p, 
div[data-testid="stToast"] span, 
div[data-testid="stToast"] svg,
[data-testid="stToast"] [data-testid="stMarkdownContainer"] p {
    color: #FFFFFF !important;
    -webkit-text-fill-color: #FFFFFF !important;
    fill: #FFFFFF !important;
    font-weight: 700 !important;
    font-size: 14px !important;
}

/* ── Navbar (Segmented Control) Style (Aggressive Dark) ── */
div[data-testid="stSegmentedControl"],
[data-testid="stSegmentedControl"] > div,
.st-key-active_tab,
.st-key-active_tab > div {
    background-color: #050212 !important;
    background: #050212 !important;
    border: 1px solid rgba(139, 92, 246, 0.3) !important;
    border-radius: 14px !important;
    padding: 6px !important;
    backdrop-filter: blur(12px) !important;
    box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.4) !important;
}

/* Individual Buttons inside Navbar */
div[data-testid="stSegmentedControl"] button,
.st-key-active_tab button {
    background-color: transparent !important;
    border: none !important;
    transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
}

div[data-testid="stSegmentedControl"] button p,
.st-key-active_tab button p {
    color: #C4B5FD !important;
    -webkit-text-fill-color: #C4B5FD !important;
    font-weight: 600 !important;
    font-size: 13px !important;
}

/* Active Tab Style */
div[data-testid="stSegmentedControl"] button[aria-selected="true"],
div[data-testid="stSegmentedControl"] button[data-checked="true"],
.st-key-active_tab button[aria-selected="true"],
.st-key-active_tab button[data-checked="true"] {
    background: linear-gradient(135deg, #7C3AED, #4C1D95) !important;
    border-radius: 10px !important;
    box-shadow: 0 4px 15px rgba(124, 58, 237, 0.4) !important;
}

div[data-testid="stSegmentedControl"] button[aria-selected="true"] p,
div[data-testid="stSegmentedControl"] button[data-checked="true"] p,
.st-key-active_tab button[aria-selected="true"] p {
    color: #FFFFFF !important;
    -webkit-text-fill-color: #FFFFFF !important;
    font-weight: 800 !important;
    opacity: 1 !important;
}
div[data-testid="stSegmentedControl"] button:hover {
    background: rgba(139, 92, 246, 0.15) !important;
    border-radius: 10px !important;
}
div[data-testid="stSegmentedControl"] button:hover p {
    color: #FFFFFF !important;
    opacity: 1;
}
</style>
""", unsafe_allow_html=True)

# ── Session defaults ──────────────────────────────────────────────────────────
DEFAULTS = dict(logged_in=False, email="", name="", user_platforms=[],
                live_results=None, last_query="", search_history=[],
                compare_list=[], show_compare=False, show_wishlist=False,
                theme="dark", active_tab="🔍 Search", trigger_search=False)
for k, v in DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

def inject_theme():
    t = st.session_state.get("theme", "dark")
    if t == "dark":
        vars = """
        :root {
          --bg: #0D0520;
          --bg-grad: linear-gradient(135deg, #0D0520 0%, #1A0B3B 50%, #0D0520 100%);
          --text: #efe0ff;
          --text-muted: rgba(167, 139, 250, .6);
          --surf: rgba(26, 11, 59, 0.85);
          --bord: rgba(139, 92, 246, 0.5);
          --acc: #A78BFA;
          --acc-grad: linear-gradient(135deg, #A78BFA, #E879F9);
          --card-bg: linear-gradient(145deg, rgba(13,5,32,.97), rgba(26,11,59,.98));
          --shdow: 0 8px 32px rgba(0,0,0,0.5);
          --inp-bg: rgba(26, 11, 59, 0.85);
          --tab-bg: rgba(139,92,246,.08);
          --tab-act: linear-gradient(135deg, #4C1D95, #7C3AED);
          --btn-bg: linear-gradient(135deg, #1E1B4B, #312E81);
          --btn-txt: #FFFFFF;
          --hero-bg: linear-gradient(135deg, rgba(124,58,237,.18), rgba(236,72,153,.12), rgba(6,182,212,.1));
          --ai-bg: rgba(245,158,11,.06);
          --ai-txt: #FCD34D;
        }
        """
    else:
        vars = """
        :root {
          --bg: #F8FAFC;
          --bg-grad: linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 50%, #E2E8F0 100%);
          --text: #1E293B;
          --text-muted: rgba(71, 85, 105, 0.7);
          --surf: rgba(255, 255, 255, 0.9);
          --bord: rgba(109, 40, 217, 0.2);
          --acc: #6D28D9;
          --acc-grad: linear-gradient(135deg, #6D28D9, #4F46E5);
          --card-bg: linear-gradient(145deg, #FFFFFF, #F8FAFC);
          --shdow: 0 8px 32px rgba(0,0,0,0.08);
          --inp-bg: #FFFFFF;
          --tab-bg: rgba(109,40,217,.05);
          --tab-act: linear-gradient(135deg, #6D28D9, #4F46E5);
          --btn-bg: linear-gradient(135deg, #6D28D9, #4F46E5);
          --btn-txt: #FFFFFF;
          --hero-bg: linear-gradient(135deg, rgba(109,40,217,.05), rgba(79,70,229,.05), rgba(30,58,138,.05));
          --ai-bg: rgba(245,158,11,.08);
          --ai-txt: #92400E;
        }
        """
    st.markdown(f"<style>{vars}</style>", unsafe_allow_html=True)

inject_theme()

# ── Session persistence logic ─────────────────────────────────────────────────
if not st.session_state.logged_in:
    sid = st.query_params.get("sid")
    if sid:
        # Avoid infinite recursion or redundant calls
        res = api("get", f"/auth/session?sid={sid}")
        if res:
            st.session_state.update(
                logged_in=True, 
                email=res["email"], 
                name=res["name"],
                user_platforms=res["platforms"].split(",")
            )
            # st.rerun()  # Optional, but helps clean up any intermediate states


ALL_PLATS = ["Amazon", "Flipkart", "Croma", "Reliance Digital"]

# Short trending names — uniform chip width
TRENDING = [
    ("Samsung S24", "Samsung Galaxy S24 Ultra"),
    ("iPhone 15 Pro", "iPhone 15 Pro"),
    ("PlayStation 5", "PlayStation 5 Console"),
    ("MacBook Air M3", "MacBook Air M3 Laptop"),
    ("OnePlus 12", "OnePlus 12 5G"),
    ("AirPods Pro 2", "Apple AirPods Pro 2"),
    ("iPad Air M2", "iPad Air M2 Tablet"),
    ("MX Master 3S", "Logitech MX Master 3S"),
    ("Bose QC Ultra", "Bose QuietComfort Ultra"),
    ("Dyson V15", "Dyson V15 Detect Vacuum"),
]

def check_notifications():
    if not st.session_state.get("logged_in"): return
    email = st.session_state.email
    data = api("get", "/alerts", params={"email": email})
    if data and data.get("alerts"):
        triggered = [a for a in data["alerts"] if a["triggered"]]
        if triggered:
            for al in triggered:
                st.toast(f"🎉 Price Drop! {al['product'][:30]}... is now below ₹{al['target_price']:,.0f}!", icon="🔔")
            
            # Show a persistent banner if there's at least one triggered
            st.markdown(f"""
            <div style='background:rgba(16,185,129,0.15); border:1.5px solid #10B981; 
                        border-radius:12px; padding:15px; margin-bottom:20px; color:#10B981; font-weight:700;'>
            🔔 You have {len(triggered)} triggered price alert(s). Check the "My Alerts" tab for details!
            </div>
            """, unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════════════════
# LOGIN
# ════════════════════════════════════════════════════════════════════════════
if not st.session_state.logged_in:
    c1, c2 = st.columns([9, 1])
    with c2:
        theme_icon = "☀️" if st.session_state.theme == "dark" else "🌙"
        if st.button(theme_icon, key="login_theme", help="Toggle Theme"):
            st.session_state.theme = "light" if st.session_state.theme == "dark" else "dark"
            st.rerun()

    st.markdown("""
    <div style='text-align:center;padding:10px 0 36px;'>
      <div style='font-size:58px;font-weight:900;
        background:linear-gradient(90deg,#A78BFA,#EC4899,#06B6D4);
        -webkit-background-clip:text;-webkit-text-fill-color:transparent;
        background-clip:text;line-height:1.1;'>IntelliPrice</div>
      <div style='font-size:14px;color:rgba(167,139,250,.6);margin-top:10px;letter-spacing:.4px;'>
        AI-Powered Electronics Price Comparison &nbsp;·&nbsp;
        FastAPI &nbsp;·&nbsp; SQLite &nbsp;·&nbsp; NLP Matching
      </div>
    </div>""", unsafe_allow_html=True)

    _, cm, _ = st.columns([1, 1.1, 1])
    with cm:
        st.markdown('<div class="login-glass">', unsafe_allow_html=True)
        tl, ts = st.tabs(["🔐  Login", "✨  Sign Up"])
        with tl:
            with st.form("lf"):
                em = st.text_input("Email ID", placeholder="📧 Enter your email")
                pw = st.text_input("Password", type="password", placeholder="🔑 Enter password")
                if st.form_submit_button("🚀 Login", use_container_width=True):
                    res = api("post", "/auth/login", json={"email": em, "password": pw})
                    if res:
                        st.session_state.update(logged_in=True, email=res["email"], name=res["name"],
                            user_platforms=res["platforms"].split(","))
                        # Save session ID to URL
                        if "session_id" in res:
                            st.query_params["sid"] = res["session_id"]
                        st.success(f"🎉 Welcome back, {res['name']}!"); st.rerun()
        with ts:
            with st.form("sf"):
                nn  = st.text_input("Full Name", placeholder="👤 Enter your name")
                ne  = st.text_input("Email ID", placeholder="📧 Enter your email")
                npw = st.text_input("Password", type="password", placeholder="🔑 Choose password")
                plt = st.multiselect("Preferred Platforms", ALL_PLATS, default=ALL_PLATS)
                if st.form_submit_button("🎉 Create Account", use_container_width=True):
                    if not nn or not ne or not npw:
                        st.error("Name, Email and Password are required.")
                    elif not re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", ne):
                        st.error("📧 Please enter a valid email address.")
                    elif len(npw) < 8:
                        st.error("🔑 Password must be at least 8 characters long.")
                    else:
                        res = api("post", "/auth/register",
                                  json={"name": nn, "email": ne, "password": npw,
                                        "platforms": ",".join(plt or ALL_PLATS)})
                        if res: st.success("✅ Account created! Please log in.")
        st.markdown("</div>", unsafe_allow_html=True)
    st.stop()

# ── Check Notifications ───────────────────────────────────────────────────────
check_notifications()

# ════════════════════════════════════════════════════════════════════════════
# MAIN APP
# ════════════════════════════════════════════════════════════════════════════
valid_defaults = [p for p in st.session_state.user_platforms if p in ALL_PLATS] or ALL_PLATS

# ── Navbar ────────────────────────────────────────────────────────────────────
n1, n2, n3 = st.columns([2, 5, 3])
with n1:
    st.markdown("""<div style='padding:10px 0;'>
      <div class='brand-logo'>IntelliPrice</div>
      <div class='brand-sub'>v2.0 · AI POWERED</div>
    </div>""", unsafe_allow_html=True)
with n2:
    st.markdown("""<div style='text-align:center;padding:18px 0 0;font-size:12px;
      color:var(--text-muted);'>
      FastAPI &nbsp;·&nbsp; SQLite &nbsp;·&nbsp; TF-IDF NLP &nbsp;·&nbsp;
      scikit-learn &nbsp;·&nbsp; Streamlit</div>""", unsafe_allow_html=True)
with n3:
    st.markdown(f"""<div style='text-align:right;padding-top:6px;margin-bottom:4px;
      font-size:13px;color:var(--text);font-weight:600;'>
      👋 Hello, <span style='color:var(--acc);text-shadow:0 0 10px rgba(167,139,250,0.4);'>{st.session_state.name}</span></div>""",
      unsafe_allow_html=True)
    b1, b2 = st.columns([1.2, 0.8])
    with b1:
        theme_label = "☀️ Light Mode" if st.session_state.theme == "dark" else "🌙 Dark Mode"
        if st.button(theme_label, key="nb_theme", help="Toggle Theme", use_container_width=True):
            st.session_state.theme = "light" if st.session_state.theme == "dark" else "dark"
            st.rerun()
    with b2:
        if st.button("🚪 Logout", key="nb_lo", help="Logout", use_container_width=True):
            sid = st.query_params.get("sid")
            if sid:
                api("delete", f"/auth/logout?sid={sid}")
            st.query_params.clear()
            for k, v in DEFAULTS.items(): st.session_state[k] = v
            st.rerun()

st.markdown("<div style='height:2px;background:linear-gradient(90deg,"
            "transparent,var(--bord),transparent);margin:0 0 16px;'></div>",
            unsafe_allow_html=True)

# ── Hero ──────────────────────────────────────────────────────────────────────
st.markdown("""<div class='hero'>
  <div class='hero-title'>💡 AI-Powered Live Price Comparison
    <span class='pill-ai'>🤖 AI + NLP</span></div>
  <div class='hero-sub'>
    Scrapes <b style='color:#A78BFA;'>Amazon, Flipkart, Croma &amp; Reliance Digital</b> live.
    Uses <b style='color:#6EE7B7;'>TF-IDF NLP</b> for product matching,
    <b style='color:#EC4899;'>RandomForest</b> for deal scoring, and
    <b style='color:#FCD34D;'>LinearRegression</b> for price prediction.
  </div>
</div>""", unsafe_allow_html=True)

# ── Search panel (Global) ──────────────────────────────────────────────────
st.markdown("""<div class='search-panel'>
  <div class='search-title'>🔍 Live Price Search
    <span class='live-badge'>LIVE</span></div>
  <div class='search-sub'>
    Searches all platforms simultaneously — AI groups identical product variants</div>
</div>""", unsafe_allow_html=True)

def _set_q(val):
    st.session_state["q_in"] = val
    st.session_state["active_tab"] = "🔍 Search"
    st.session_state["trigger_search"] = True

def _rm_q(val):
    if val in st.session_state.search_history:
        st.session_state.search_history.remove(val)
    st.rerun()

# ── Search controls ──────────────────────────────────────────────────
# Row 1: Search Input
st.markdown("<div class='search-row'>", unsafe_allow_html=True)
query = st.text_input("Search", key="q_in",
                      placeholder="e.g. Samsung Galaxy S24, iPhone 15, Sony WH-1000XM5",
                      label_visibility="collapsed")
st.markdown("</div>", unsafe_allow_html=True)

# Row 2: Filters & Button
sc1, sc2, sc3 = st.columns([2.5, 1.5, 1])
with sc1:
    sel_plats = st.multiselect("Platforms", ALL_PLATS,
                               default=valid_defaults,
                               label_visibility="collapsed")
with sc2:
    sort_by = st.selectbox("Sort", ["Best Deal", "Price ↑", "Price ↓", "Rating ↓"],
                           label_visibility="collapsed")
with sc3:
    do_search = st.button("🔍 Search", key="btn_go", use_container_width=True)

# ── Auto-search Trigger ──
if st.session_state.get("trigger_search") and st.session_state.get("q_in"):
    query = st.session_state["q_in"]
    st.session_state["trigger_search"] = False
    do_search = True

# ── Run search ────────────────────────────────────────────────────────
if do_search and query.strip():
    with st.spinner(f"🤖 Scraping live prices for **{query}** …"):
        data = api("get", "/search",
                   params={"q": query.strip(),
                           "platforms": ",".join(sel_plats or ALL_PLATS),
                           "email":  st.session_state.email})
    if data:
        for k in list(st.session_state.keys()):
            if k.startswith("show_al_") or k.startswith("al_val_"):
                del st.session_state[k]
        st.session_state.live_results = data
        st.session_state.last_query   = query.strip()
        hist = st.session_state.search_history
        if query.strip() not in hist:
            hist.append(query.strip())
        st.session_state.search_history = hist[-10:]
        st.rerun()

st.markdown("<br>", unsafe_allow_html=True)

# ── Navigation Tabs (Stateful) ────────────────────────────────────────────────
tabs = ["🔍 Search", "❤️ Wishlist", "⚖️ Compare", "📊 History", "🔔 Alerts", "📈 Prediction"]
active_tab = st.segmented_control("Navigation", tabs, 
                                  key="active_tab", 
                                  label_visibility="collapsed")

st.markdown("<br>", unsafe_allow_html=True)

if active_tab == "🔍 Search":
        # ── Trending chips (2 rows of 5) ─────────────────────────────────────
        st.markdown("<div style='font-size:13px;font-weight:700;color:var(--acc);margin-bottom:6px;'>"
                    "🔥 Trending Searches</div>", unsafe_allow_html=True)
    
        st.markdown("<div class='trend-btn'>", unsafe_allow_html=True)
        row1_cols = st.columns(5)
        row2_cols = st.columns(5)
        for i, (label, full) in enumerate(TRENDING):
            col = row1_cols[i] if i < 5 else row2_cols[i - 5]
            with col:
                st.button(label, key=f"tc_{i}", on_click=_set_q, args=(full,))
        st.markdown("</div>", unsafe_allow_html=True)


# ── Render results ────────────────────────────────────────────────────
if active_tab == "🔍 Search" and st.session_state.live_results:
        data   = st.session_state.live_results
        groups = data.get("groups", [])
        summ   = data.get("summary", {})
        q_disp = st.session_state.last_query

        if not groups:
            st.markdown(f"""<div class='no-res'>
              <div style='font-size:17px;font-weight:700;color:#FCD34D;margin-bottom:8px;'>
                😕 No results for "<b>{q_disp}</b>"</div>
              <div style='font-size:12px;color:rgba(253,211,77,.75);'>
                💡 Tips: Try a shorter query · Select "Amazon" only · Wait 30 s and retry
              </div></div>""", unsafe_allow_html=True)
        else:
            # ── Stats bar ─────────────────────────────────────────────
            st.markdown("<br>", unsafe_allow_html=True)
            for col, val, lbl in zip(
                st.columns(4),
                [summ.get("total_products","—"), summ.get("total_platforms","—"),
                 f"₹{summ.get('max_savings', 0):,}", len(summ.get("hot_deals",[]))],
                ["Products Found","Platforms Live","Max Savings","Hot Deals"]
            ):
                with col:
                    st.markdown(f"<div class='stat-card'>"
                                f"<div class='stat-val'>{val}</div>"
                                f"<div class='stat-lbl'>{lbl}</div></div>",
                                unsafe_allow_html=True)
            st.markdown("<br>", unsafe_allow_html=True)

            # ── Hot deals banner ──────────────────────────────────────
            hd = summ.get("hot_deals", [])
            if hd:
                pills = " ".join(
                    f"<span class='hot-pill'>🔥 {d['product'][:26]} "
                    f"— {d['platform']} @ ₹{d['price']:,} "
                    f"<span style='color:#6EE7B7;font-weight:700;'>(-{d['savings_pct']}%)</span>"
                    f"</span>" for d in hd)
                st.markdown(f"<div class='hot-wrap'>"
                            f"<div style='font-size:13px;font-weight:800;color:#C4B5FD;"
                            f"margin-bottom:8px;'>🤖 AI Hot Deals — 10%+ cross-platform gap</div>"
                            f"{pills}</div>", unsafe_allow_html=True)

            # ── Platform filter ───────────────────────────────────────
            fp_all, fp_az, fp_fk, fp_cr, fp_rd = st.columns(5)
            fp = st.session_state.get("fp", "All")
            with fp_all:
                if st.button("All",             key="fp_all"): st.session_state["fp"]="All";            st.rerun()
            with fp_az:
                if st.button("Amazon",          key="fp_az"):  st.session_state["fp"]="Amazon";         st.rerun()
            with fp_fk:
                if st.button("Flipkart",        key="fp_fk"):  st.session_state["fp"]="Flipkart";       st.rerun()
            with fp_cr:
                if st.button("Croma",           key="fp_cr"):  st.session_state["fp"]="Croma";          st.rerun()
            with fp_rd:
                if st.button("Reliance",        key="fp_rd"):  st.session_state["fp"]="Reliance Digital";st.rerun()


            # ── Platform filter ───────────────────────────────────────

            # ── Sort groups ───────────────────────────────────────────
            def apply_sort(g_list):
                if sort_by == "Price ↑":
                    return sorted(g_list, key=lambda g: g["best_price"])
                if sort_by == "Price ↓":
                    return sorted(g_list, key=lambda g: -g["best_price"])
                if sort_by == "Rating ↓":
                    return sorted(g_list, key=lambda g: -(
                        max((r["rating"] for r in g.get("platform_rows",[])),default=0)))
                return g_list

            sorted_groups = apply_sort(groups)

            # ── Wishlist & alert data ─────────────────────────────────
            wl_res = api("get", "/wishlist",
                         params={"email": st.session_state.email}) or {}
            wishlist_items = wl_res.get("items", [])
            al_res = api("get", "/alerts",
                         params={"email": st.session_state.email}) or {}
            all_alerts = {a["product"]: a["target_price"]
                          for a in al_res.get("alerts", [])}

            # ── Product grid ──────────────────────────────────────────
            st.markdown(
                f"<div style='font-size:19px;font-weight:900;"
                f"background:linear-gradient(90deg,#A78BFA,#EC4899);"
                f"-webkit-background-clip:text;-webkit-text-fill-color:transparent;"
                f"background-clip:text;margin:16px 0 12px;'>"
                f"🔥 {q_disp} — AI Price Comparison</div>",
                unsafe_allow_html=True)

            RC   = ["pr-1","pr-2","pr-3","pr-4"]
            cols = st.columns(2)
            _k   = [0]

            for result in sorted_groups:
                pname  = result.get("product_name","")
                p_rows = result.get("platform_rows",[])

                # Platform filter
                if fp != "All":
                    p_rows = [r for r in p_rows if r["platform"] == fp]
                if not p_rows:
                    continue

                _k[0] += 1; wn = _k[0]

                with cols[(_k[0]-1) % 2]:
                    st.markdown('<div class="pcard">', unsafe_allow_html=True)

                    # Alert badge
                    t_alert = all_alerts.get(pname)
                    alert_badge = ""
                    if t_alert:
                        if result["best_price"] <= t_alert:
                            alert_badge = (f"<span class='badge-alert'>"
                                           f"🔔 ALERT! ₹{result['best_price']:,} ≤ ₹{t_alert:,}</span>")
                        else:
                            alert_badge = f"<span class='badge-alert'>🔔 Target ₹{t_alert:,}</span>"

                    st.markdown(f"""
<div class='pcard-name'>📦 {pname[:66]}</div>
<div class='pcard-meta'>
  <span class='badge-plat'>{result['platforms_found']} platforms</span>
  <span class='badge-save'>Save ₹{result['spread']:,} ({result['spread_pct']}%)</span>
  {alert_badge}
</div>""", unsafe_allow_html=True)

                    # Product image — HTML img with no-referrer bypass + auto-hide on error
                    img = result.get("image","")
                    if img and img.startswith("http"):
                        st.markdown(
                            f"""<img src="{img}" width="180" loading="lazy"
                              referrerpolicy="no-referrer"
                              style="border-radius:10px;margin:6px 0 10px;
                                     display:block;max-width:100%;object-fit:contain;"
                              onerror="this.style.display='none'">""",
                            unsafe_allow_html=True)

                    # AI box
                    st.markdown(f"""<div class='ai-box'>
<div class='ai-box-title'>🤖 AI RECOMMENDATION</div>
<div class='ai-box-rec'>{result['recommendation']}</div>
<div class='ai-avg'>Avg ₹{result['avg_price']:,} ·
<span class='ai-best'>Best ₹{result['best_price']:,} on {result['best_platform']}</span>
</div></div>""", unsafe_allow_html=True)

                    # Platform rows
                    for row in p_rows:
                        rc   = RC[min(row["rank"]-1, 3)]
                        best_tag = "<span class='plat-best'>✅ BEST</span>" if row["is_cheapest"] else ""
                        disc_tag = (f"<span class='plat-disc'>-{row['discount_pct']}%</span>"
                                    if row["discount_pct"] > 0 else "")
                        orig_tag = (f"<span class='plat-orig'>₹{row['original_price']:,}</span>"
                                    if row["original_price"] > row["price"] else "")
                        stars    = (f"<span style='font-size:10px;color:#FCD34D;'>"
                                    f"⭐ {row['rating']:.1f}</span>"
                                    if row["rating"] > 0 else "")
                        diff_tag = (
                            "<span style='font-size:11px;color:#6EE7B7;'>✅ Lowest Price</span>"
                            if row["is_cheapest"] else
                            f"<span style='font-size:11px;color:rgba(252,165,165,.8);'>"
                            f"+₹{row['price']-result['best_price']:,} vs best</span>")
                        offer    = row.get("offer_text","")
                        offer_h  = f"<div class='offer-pill'>🏷️ {offer[:55]}</div>" if offer else ""
                        fake_h   = "<span class='badge-fake'>⚠️ Fake Discount?</span>" if row.get("fake_discount") else ""
                        est_h    = "<span class='badge-est'>~Estimated</span>" if row.get("is_estimated") else ""
                        sw       = int(row["deal_score"] * 100)

                        st.markdown(f"""<div class='plat-row {rc}'>
<div style='display:flex;align-items:center;justify-content:space-between;'>
<div class='plat-name'>🛒 {row['platform']} {best_tag} {est_h}</div>
<div>{disc_tag} {stars}</div>
</div>
<div style='display:flex;align-items:baseline;gap:6px;'>
<div class='plat-price'>₹{row['price']:,}</div>
{orig_tag}
</div>
{fake_h}
<div style='margin-top:2px;'>{diff_tag}</div>
{offer_h}
<div class='score-bg'>
<div class='score-bar' style='width:{sw}%;'></div>
</div>
<div class='score-txt'>AI Deal Score: {row['deal_score']:.3f}/1.0</div>
</div>""", unsafe_allow_html=True)

                        if row.get("url"):
                            st.link_button(f"🔗 Buy on {row['platform']} →",
                                           row["url"])

                    # ── Action buttons ────────────────────────────────
                    ba1, ba2, ba3 = st.columns(3)
                    with ba1:
                        if pname in wishlist_items:
                            if st.button("💔 Remove From Wishlist", key=f"rm_w{wn}", use_container_width=True):
                                api("delete", "/wishlist",
                                    params={"email": st.session_state.email,
                                            "product": pname})
                                st.rerun()
                        else:
                            if st.button("❤️ Wishlist", key=f"add_w{wn}", use_container_width=True):
                                api("post", "/wishlist",
                                    json={"email": st.session_state.email,
                                          "product": pname})
                                st.rerun()
                    with ba2:
                        cur_al = all_alerts.get(pname)
                        if cur_al:
                            if st.button("🔕 Remove Alert", key=f"rm_al{wn}", use_container_width=True):
                                api("delete", "/alerts",
                                    params={"email": st.session_state.email,
                                            "product": pname})
                                st.rerun()
                        else:
                            if st.button("🔔 Set Alert", key=f"set_al{wn}", use_container_width=True):
                                st.session_state[f"show_al_{pname}"] = True
                    with ba3:
                        already = any(c["product_name"] == pname
                                      for c in st.session_state.compare_list)
                        if already:
                            if st.button("⚖️ Added ✓", key=f"cmp_rm{wn}", use_container_width=True):
                                st.session_state.compare_list = [
                                    c for c in st.session_state.compare_list
                                    if c["product_name"] != pname]
                                st.rerun()
                        else:
                            if st.button("⚖️ Compare", key=f"cmp_add{wn}", use_container_width=True):
                                st.session_state.compare_list.append(result)
                                st.session_state.show_compare = True
                                st.rerun()

                    # Price alert number input
                    if st.session_state.get(f"show_al_{pname}"):
                        tprice = st.number_input(
                            f"Set target ₹ for {pname[:24]}…",
                            min_value=100, max_value=10_000_000,
                            value=result["best_price"], step=500,
                            key=f"al_val_{pname}")
                        if st.button("✅ Confirm Alert", key=f"conf_al{wn}"):
                            api("post", "/alerts",
                                json={"email": st.session_state.email,
                                      "product": pname, "target_price": tprice})
                            st.session_state[f"show_al_{pname}"] = False
                            st.success(f"🔔 Alert set for ₹{tprice:,}!")
                            st.rerun()

                    st.markdown("</div>", unsafe_allow_html=True)


# ════════════════════════════════════════════════════════════════════════════
# TAB — WISHLIST
# ════════════════════════════════════════════════════════════════════════════
elif active_tab == "❤️ Wishlist":
    st.markdown("### ❤️ My Wishlist")
    st.markdown("<div style='font-size:12px;color:var(--text-muted);margin-bottom:16px;'>"
                "Products you've saved from search results</div>",
                unsafe_allow_html=True)
    wl_data = (api("get", "/wishlist",
                   params={"email": st.session_state.email}) or {}).get("items", [])
    if not wl_data:
        st.info("Wishlist is empty — hit ❤️ on any product card in the Search tab to save it.")
    else:
        for i_wl, item in enumerate(wl_data):
            pname = item.get("product", "Unknown Product")
            pimg  = item.get("image", "")
            
            with st.container():
                # Use a custom div to group the item but let Streamlit handle the buttons
                st.markdown(f"""
                <div style='background:var(--surf); border:1px solid var(--bord); border-radius:16px; padding:12px; margin-bottom:12px;'>
                    <div style='display:flex; align-items:center; gap:16px;'>
                        <img src='{pimg}' style='width:60px; height:60px; border-radius:10px; object-fit:contain; background:white;' 
                             onerror="this.src='https://cdn-icons-png.flaticon.com/512/679/679821.png'">
                        <div style='flex-grow:1;'>
                            <div style='font-size:14px; font-weight:800; color:var(--text); line-height:1.4;'>{pname[:80]}...</div>
                            <div style='font-size:11px; color:var(--acc); font-weight:700; margin-top:4px;'>❤️ Saved to Wishlist</div>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Action buttons below the card but associated with it
                bc1, bc2 = st.columns([8, 2])
                with bc1:
                    st.button(f"🔍 Research {pname[:20]}...", key=f"btn_wl_go_{i_wl}", 
                              use_container_width=True, on_click=_set_q, args=(pname,))
                with bc2:
                    if st.button("🗑️", key=f"del_wl_tab_{i_wl}", help="Remove from wishlist", use_container_width=True):
                        api("delete", "/wishlist", params={"email": st.session_state.email, "product": pname})
                        st.rerun()
                st.markdown("<div style='margin-bottom:20px;'></div>", unsafe_allow_html=True)



    # ════════════════════════════════════════════════════════════════════════════
# TAB — COMPARE
# ════════════════════════════════════════════════════════════════════════════
elif active_tab == "⚖️ Compare":
    st.markdown("### ⚖️ Side-by-Side Comparison")
    st.markdown("<div style='font-size:12px;color:var(--text-muted);margin-bottom:16px;'>"
                "Compare products added from search results</div>",
                unsafe_allow_html=True)
    if st.session_state.compare_list:
        cmp_rows = []
        for cg in st.session_state.compare_list:
            for pr in cg.get("platform_rows", []):
                cmp_rows.append({
                    "Product":    cg["product_name"][:30],
                    "Platform":   pr["platform"],
                    "Price":      f"₹{pr['price']:,}",
                    "MRP":        f"₹{pr['original_price']:,}",
                    "Discount":   f"{pr['discount_pct']}%",
                    "Rating":     f"⭐ {pr['rating']}" if pr['rating'] else "—",
                    "Deal Score": pr['deal_score'],
                    "Source":     "~Est." if pr.get('is_estimated') else "LIVE",
                })
        if cmp_rows:
            st.dataframe(pd.DataFrame(cmp_rows), use_container_width=True, hide_index=True)
        if st.button("🗑️ Clear Compare List", key="clr_cmp_tab"):
            st.session_state.compare_list = []
            st.rerun()
    else:
        st.info("No products to compare yet. Use the ⚖️ Compare button on product cards in the Search tab.")


    # ════════════════════════════════════════════════════════════════════════════
# TAB — HISTORY
# ════════════════════════════════════════════════════════════════════════════
elif active_tab == "📊 History":
    st.markdown("### 📊 Search History & Trends")
    st.markdown("<div style='font-size:12px;color:var(--text-muted);margin-bottom:16px;'>"
                "Your recent searches — click any to re-search</div>",
                unsafe_allow_html=True)
    h_list = list(reversed(st.session_state.search_history[-10:])) if st.session_state.search_history else []
    if not h_list:
        st.info("No search history yet. Search for products in the Search tab to build your history.")
    else:
        def _set_q_hist(val):
            st.session_state["q_in"] = val
        def _rm_q_hist(val):
            if val in st.session_state.search_history:
                st.session_state.search_history.remove(val)
            st.rerun()
        # Fetch images for history
        h_images = {}
        if h_list:
            hist_imgs_raw = api("get", "/search/history-images", params={"queries": ",".join(h_list)})
            if hist_imgs_raw:
                h_images = {it["query"]: it["image"] for it in hist_imgs_raw.get("items", [])}

        for i_h, h_q in enumerate(h_list):
            img_url = h_images.get(h_q, "")
            with st.container():
                st.markdown(f"""
                <div style='background:var(--surf); border:1px solid var(--bord); border-radius:12px; padding:10px; margin-bottom:8px;'>
                    <div style='display:flex; align-items:center; gap:12px;'>
                        <div style='width:40px; height:40px; display:flex; align-items:center; justify-content:center; background:rgba(167,139,250,0.1); border-radius:8px;'>
                            <span style='font-size:18px;'>🔍</span>
                        </div>
                        <div style='flex-grow:1; font-size:13px; font-weight:700; color:var(--text);'>{h_q}</div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                hc1, hc2 = st.columns([9, 1])
                with hc1:
                    st.button(f"🔍 Search again: {h_q[:30]}", key=f"hist_tab_{i_h}", 
                              use_container_width=True, on_click=_set_q, args=(h_q,))
                with hc2:
                    if st.button("✕", key=f"hist_tab_rm_{i_h}", help="Remove from history", use_container_width=True):
                        _rm_q_hist(h_q)
                st.markdown("<div style='margin-bottom:12px;'></div>", unsafe_allow_html=True)
        if st.button("🗑️ Clear All History", key="clr_hist"):
            st.session_state.search_history = []
            st.rerun()


    # ════════════════════════════════════════════════════════════════════════════
# TAB — ALERTS
# ════════════════════════════════════════════════════════════════════════════
elif active_tab == "🔔 Alerts":
    st.markdown("### 🔔 Smart Price Alerts")
    st.markdown("<div style='font-size:12px;color:var(--text-muted);margin-bottom:16px;'>"
                "Alerts trigger when: price ≤ target (AI-validated)</div>",
                unsafe_allow_html=True)
    raw_al = (api("get", "/alerts",
                  params={"email": st.session_state.email}) or {}).get("alerts",[])
    if not raw_al:
        st.info("No alerts set. In the Search tab, click 🔔 on any product card.")
    else:
        for al in raw_al:
            color  = "#6EE7B7" if al["triggered"] else "#A78BFA"
            status = "✅ Triggered!" if al["triggered"] else "🟢 Watching"
            st.markdown(f"""<div style='background:var(--tab-bg);
              border:1px solid var(--bord);border-radius:12px;
              padding:13px 16px;margin-bottom:10px;'>
              <div style='font-size:13px;font-weight:700;color:var(--text);'>
                📦 {al['product']}</div>
              <div style='font-size:11px;color:var(--text-muted);margin-top:4px;'>
                Target: <b style='color:{color};'>₹{al['target_price']:,.0f}</b>
                &nbsp;·&nbsp; {status}
                &nbsp;·&nbsp; {al.get('created_at','')[:10]}
              </div></div>""", unsafe_allow_html=True)
        
            ac1, ac2 = st.columns(2)
            with ac1:
                if st.button(f"🗑️ Remove Alert", key=f"del_al_{al['id']}", use_container_width=True):
                    api("delete", "/alerts",
                        params={"email": st.session_state.email,
                                "product": al["product"]})
                    st.rerun()
            with ac2:
                if al["triggered"]:
                    if st.button(f"👁️ Got it (Reset)", key=f"res_al_{al['id']}", use_container_width=True):
                        api("post", "/alerts/reset",
                            json={"email": st.session_state.email,
                                  "product": al["product"]})
                        st.rerun()

    # ════════════════════════════════════════════════════════════════════════════
# TAB 3 — PRICE PREDICTION
# ════════════════════════════════════════════════════════════════════════════
elif active_tab == "📈 Prediction":
    st.markdown("### 📈 Price Prediction — LinearRegression")
    st.markdown("<div style='font-size:12px;color:var(--text-muted);margin-bottom:16px;'>"
                "Requires ≥ 3 price records. Prices are recorded every time you search.</div>",
                unsafe_allow_html=True)
    pc1, pc2 = st.columns([3, 1])
    with pc1:
        pred_prod = st.text_input("Product name (exact)",
                                  placeholder="e.g. Samsung Galaxy S24 Ultra",
                                  key="pp_prod")
    with pc2:
        pred_plat = st.selectbox("Platform", ALL_PLATS, key="pp_plat")

    if st.button("📈 Predict Price Trend", key="do_pred", use_container_width=True):
        pred = api("get", "/predict-price",
                   params={"product": pred_prod, "platform": pred_plat})
        if pred and "predicted_price" in pred:
            # Header with Image & Name
            pred_image = pred.get("image", "")
            if pred_image and pred_image.startswith("http"):
                img_html = f"<img src='{pred_image}' width='100' style='border-radius:10px;object-fit:contain;' onerror=\"this.style.display='none';this.nextElementSibling.style.display='flex';\"><div style='display:none;width:100px;height:100px;background:rgba(139,92,246,0.15);border-radius:10px;align-items:center;justify-content:center;font-size:40px;'>📦</div>"
            else:
                img_html = "<div style='width:100px;height:100px;background:rgba(139,92,246,0.15);border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:40px;'>📦</div>"
            st.markdown(f"""
<div style='display:flex;align-items:center;gap:20px;background:var(--surf);
            border:1px solid var(--bord);border-radius:18px;padding:20px;margin-bottom:20px;'>
    {img_html}
    <div>
        <div style='font-size:12px;color:var(--text-muted);font-weight:700;'>PREDICTING FOR</div>
        <div style='font-size:18px;font-weight:800;color:var(--text);'>{pred.get("product_name", pred_prod)}</div>
        <div style='font-size:12px;color:var(--acc);font-weight:700;margin-top:4px;'>🛒 {pred.get("platform", pred_plat)}</div>
    </div>
</div>
""", unsafe_allow_html=True)

            css = {"dropping":"pred-down","rising":"pred-up","stable":"pred-stable"
                   }.get(pred["trend"],"pred-stable")
        
            # Advice Box
            st.markdown(f"<div class='{css}' style='font-size:16px;font-weight:700;padding:15px;margin-bottom:15px;'>{pred['advice']}</div>",
                        unsafe_allow_html=True)
        
            # Reasoning/Explanation Box
            st.markdown(f"""
<div style='background:rgba(167,139,250,0.05);border:1.5px dashed var(--bord);
            border-radius:12px;padding:16px;margin-bottom:20px;'>
    <div style='font-size:11px;font-weight:800;color:var(--acc);margin-bottom:6px;letter-spacing:1px;'>💡 AI REASONING</div>
    <div style='font-size:13px;line-height:1.6;color:var(--text);'>{pred.get("explanation", "The model analyzes historical price points to identify trends and seasonal patterns.")}</div>
</div>
""", unsafe_allow_html=True)

            for col, val, lbl in zip(st.columns(4),
                [f"₹{pred['current_price']:,}", f"₹{pred['predicted_price']:,}",
                 f"{pred['pct_change']:+.1f}%", f"{pred['confidence']}%"],
                ["Current Price","Predicted Next","Expected Change","Model R²"]):
                with col:
                    st.markdown(f"<div class='stat-card'>"
                                f"<div class='stat-val'>{val}</div>"
                                f"<div class='stat-lbl'>{lbl}</div></div>",
                                unsafe_allow_html=True)
            # Graph
            hist = (api("get","/price-history",
                        params={"product":pred_prod,"platform":pred_plat}) or {}).get("history",[])
            if hist:
                fig, ax = plt.subplots(figsize=(10, 3.5))
                fig.patch.set_facecolor("#0D0520")
                ax.set_facecolor("#0D0520")
                prices = [h["price"] for h in hist]
                ax.plot(range(len(prices)), prices, color="#A78BFA", linewidth=2.5,
                        marker="o", markersize=4, label="Recorded Prices")
                ax.fill_between(range(len(prices)), prices, alpha=0.12, color="#8B5CF6")
                ax.scatter([len(prices)], [pred["predicted_price"]],
                           color="#EC4899", s=90, zorder=5,
                           label=f"Predicted ₹{pred['predicted_price']:,}")
                ax.yaxis.set_major_formatter(
                    mticker.FuncFormatter(lambda x, _: f"₹{int(x):,}"))
                ax.tick_params(colors="#6D5A8F", labelsize=9)
                for sp in ax.spines.values(): sp.set_visible(False)
                ax.set_xlabel("Price Observations", color="#6D5A8F", fontsize=9)
                ax.set_ylabel("Price (₹)", color="#6D5A8F", fontsize=9)
                ax.legend(fontsize=9, facecolor="#0D0520", edgecolor="#3D2B6D",
                          labelcolor="#E2D9F3")
                st.pyplot(fig)
        elif pred:
            st.warning(pred.get("error","Not enough price history yet."))

    # ── Footer ────────────────────────────────────────────────────────────────────
st.markdown("""<div class='footer'>
  <div style='font-size:13px;font-weight:700;color:rgba(167,139,250,.4);margin-bottom:5px;'>
💰 IntelliPrice 2.0 — AI Smart Electronics Price Comparison</div>
  FastAPI &nbsp;·&nbsp; SQLite &nbsp;·&nbsp; TF-IDF NLP &nbsp;·&nbsp;
  scikit-learn &nbsp;·&nbsp; Streamlit &nbsp;·&nbsp;
  <span style='color:#A78BFA;'>Amazon</span> &nbsp;·&nbsp;
  <span style='color:#EC4899;'>Flipkart</span> &nbsp;·&nbsp;
  <span style='color:#6EE7B7;'>Croma</span> &nbsp;·&nbsp;
  <span style='color:#FCD34D;'>Reliance Digital</span>
</div>""", unsafe_allow_html=True)
