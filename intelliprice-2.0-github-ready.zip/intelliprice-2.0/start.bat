@echo off
echo ======================================================
echo   IntelliPrice 2.0 — Starting servers...
echo ======================================================
echo.
echo [1/2] Starting FastAPI backend on http://localhost:8000
start "IntelliPrice API" cmd /k "cd /d %~dp0 && python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload"
timeout /t 3 /nobreak >nul
echo [2/2] Starting Streamlit frontend on http://localhost:8501
start "IntelliPrice UI" cmd /k "cd /d %~dp0 && streamlit run frontend/app.py --server.port 8501"
echo.
echo Both servers are starting...
echo   API docs:  http://localhost:8000/docs
echo   App UI:    http://localhost:8501
echo.
pause
